package com.javatechie.dto;

public class GlobalErrorCode {
    public static final String ERROR_ORDER_NOT_FOUND = "RESTAURANT-SERVICE-1000";
    public static final String GENERIC_ERROR = "RESTAURANT-SERVICE-1001";
}
