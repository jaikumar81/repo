package com;

interface test1{
default void executor() {System.out.println("Drawing inside default executor");}
}

public interface test extends test1{	
void execute(); //abstract
int x=10;
static void executes() { System.out.println("Drawing inside static executes");}

test t=()->{ System.out.println("Drawing==");};
test1 tr = new test1() {};

public static void main(String args[]) { executes();
System.out.println("Running inside main method"+"=="+x);
//test1 tr = new test1() {};

//test t =()->{}; 
t.executor();
tr.executor();
t.execute();
}
/*default void executor() {System.out.println("Drawing inside default executor");}*/

//It can contain any number of Object class methods.  
int hashCode();               //abstract
String toString();            //abstract
boolean equals(Object obj);   //abstract
}


/*public class LambdaTest {
	
	public static void main(String args[]) {
	int x =10;
		
     test t =new test() {
	
public void execute() {
	System.out.println("Drawing"+"=="+x); }
		
	};

	test t=()->{ System.out.println("Drawing=="+x); };
	
	t.execute();
	//t.executor();
	t.executor();
	test.executes();
		
	}

	
}
*/