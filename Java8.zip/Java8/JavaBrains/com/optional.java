package com;

import java.util.Arrays;
import java.util.Optional;

public class optional {
	
	static String[] str= new String[10];
	
	public static void main(String[] args) {
	//String[] str= new String[10];
    
	str[5] = "Hello Jayakumar";
		
	Optional<String> empty = Optional.empty();  
	Optional<String> opt =Optional.ofNullable(str[5]);
	Optional<String> opt1 =Optional.ofNullable(str[4]);
	//If a value is present, isPresent() will return true and get() will return the value. 
	 if(opt.isPresent()) {		
		String lowercase= str[5].toLowerCase();
		System.out.println(lowercase);
		System.out.println(Arrays.toString(str));
		
		System.out.println(opt);
		System.out.println(opt1);
		
		System.out.println("Filtered value: "+opt.filter((s)->s.equals("HelloJayakumar")));  
		System.out.println("Filtered value: "+opt.filter((s)->s.equals("Hello Jayakumar"))); 
		
		System.out.println("orElse: "+opt.orElse("Value is not present"));  
        System.out.println("orElse: "+empty.orElse("Value is not present"));  
	
	 }if(opt1.isPresent()) {
		String lowercase= str[4].toLowerCase();
		System.out.println(lowercase);
	
	 }else {
		System.out.println("The String has no value to generate Lowercase"+"::"+str[4]);
	}
	
	}
}
