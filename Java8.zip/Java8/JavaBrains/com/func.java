package com;


@FunctionalInterface //optional
public interface func {	
 void x(String s); 
 		
 public static void main(String args[]) {
	func f= (s)->{
		System.out.println("Running inside the interface"+" ,"+s);
	};
	f.x("Hello");
	
}

}

 abstract class Planet {
 protected void revolve () {
 }
 abstract void rotate();
 }

 class Earth extends Planet{
 protected void revolve () {
 }
 protected void rotate() {
 }
 }