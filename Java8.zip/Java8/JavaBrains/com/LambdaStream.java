package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.util.function.Function.identity;
import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.averagingDouble;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toCollection;

class Products {

public int id;
public String name;
public float price;
	
public Products(int id, String name, float price) {
	super();
	this.id = id;
	this.name = name;
	this.price = price;
	}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public float getPrice() {
	return price;
}

public void setPrice(float price) {
	this.price = price;
}	

@Override
public String toString() {
		return "Products [id=" + id + ", name=" + name + ", price=" + price + ", toString()=" + super.toString() + "]";
	}
}

public class LambdaStream {
	
public static void main(String [] args) {
	
//To find the largest and smallest number.	

	//int[] intarr = new int[] {120,20,40,60,80,100,10};
	int[] intarr = {120,20,40,60,80,100,10};
	
	int smaller = Integer.MIN_VALUE;
	int larger = Integer.MAX_VALUE;
	
	for(int i :intarr) {
		
		if(i>smaller) {
			smaller=i;
		
		} else if(i<larger) {
			larger=i;
		}
		
	} 
	Products pro = new Products(111, "Hello", 10000);
	System.out.println("1) to String Print:"+"  "+pro.toString());
	System.out.println("2) Smallest number in an array"+" "+smaller);
	System.out.println("3) Largest number in an array"+" "+larger);
	
//To find the largest and smallest number.		

	
//Sorted character in String	
	
//Set<String> sett = new HashSet<>();	
String s1 = "ZXYVU";
char[] c = s1.toCharArray();
Arrays.sort(c);

String se = new String(c);
System.out.println("4) Sorted characters in String"+"== "+se);

List<Integer> lst = List.of(1,2,3,1,4,5,2,4,3);  //Finding integer duplicates or String duplicates
List<Integer> duplicateList = lst.stream().filter(x->lst.stream().filter(y->y.equals(x)).count()>1).distinct().collect(Collectors.toList());
System.out.println("4A) Duplicate Integer Elements in a list    "+"== "+duplicateList);

String[] str1 = {"B","E","A","C","A","E"}; //Finding String duplicates
List<String> duplicateStr =Stream.of(str1) //We can use in alternate Arrays.stream
                                    .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                                    .entrySet()
                                    .stream()
                                    .filter(e->e.getValue()>1)
                                    .map(Map.Entry::getKey)
                                    .collect(Collectors.toList());
System.out.println("4B) Duplicate String Elements in a String array    "+"== "+duplicateStr);

String[] str2 = {"ABCD","EFGH"};
String[] RevStrin = Stream.of(str2).map(s->new StringBuilder(s).reverse().toString()).toArray(String[]::new); //StringBuffer or StringBuilder even for all in the below
String output= Stream.of(RevStrin).collect(Collectors.joining((",")));
System.out.println("4C) Reverse characters in String	"+"="+output);
Stream.of(output).forEach(s->System.out.println("4D) Reverse characters in String   "+"="+s)); 

String RevString = Stream.of(s1).map(String->new StringBuffer(s1).reverse()).collect(Collectors.joining(s1));
//String RevString = Stream.of(s1).map(s2->new StringBuffer(s2).reverse()).collect(Collectors.joining(s1));   //alternate declaration of String to s2
System.out.println("4E) Reverse characters in String	"+"="+RevString);

String RevString1 = Stream.of(s1).map(String->new StringBuilder(s1).reverse()).collect(Collectors.joining(s1));
System.out.println("4F) Reverse characters in String	"+"="+RevString1);

String RevString2 = Stream.of(s1).map(String->new StringBuilder(s1).reverse().toString()).collect(Collectors.joining(s1));
System.out.println("4G) Reverse characters in String	"+"="+RevString2);

String[] RevStringg = Stream.of(s1).map(s->new StringBuilder(s1).reverse().toString()).toArray(String[]::new); //duplicated-Used for ref only.
String RevString3 = Stream.of(RevStringg).collect(Collectors.joining((",")));
System.out.println("4H) Reverse characters in String	"+"="+RevString3);

String[] RevString4 = Stream.of(s1).map(String->new StringBuilder(s1).reverse().toString()).toArray(String[]::new);
Stream.of(RevString4).forEach(System.out::println); //prints to console
Stream.of(RevString4).forEach(s->System.out.println("4I) Reverse characters in String   "+"="+s)); 

String RevString5 = s1.chars().mapToObj(c1->String.valueOf((char)c1)).reduce((s11,s12)->s12+s11).orElse("");
System.out.println("4J) Reverse characters in String	"+"="+RevString5);



//Sorted character in String	
		
//Duplicate stringArray findings	
	
//String[] str = new String[] {"java","c++","net","jbee","java"};	

String[] str = {"D","E","A","C","B"};

 Set<String> set = new HashSet<>();
     
 for(String st : str) {  
	 //if(st.equalsIgnoreCase(st)) {
     if(!set.contains(st)) 
    	 set.add(st);
	// }  
 }System.out.println("5) Set non-duplicates printed"+set);    
 
 set.forEach(System.out::print);
 System.out.println();

//Duplicate stringArray findings	     
     
 //To find any duplicates is present or not??   
     
     List<String> ls = Arrays.asList(str);
     Set<String> st = new HashSet<>(ls);
     if(ls.size()!=st.size()) 
     {
             System.out.println("6) The list contains duplicates"+ls);	
     } else { 
    	     System.out.println("7) The list doesn't contains any duplicates");
    	    }
     
//To find any duplicates is present or not??    
     
     
 //To Print in ascending and descending orders   
     
     Arrays.sort(str);
     /*for(String sort:str) {
    	 System.out.print("Sorted string in ascending orders"+"=="+sort);
    	 System.out.println();
       }*/
     List<String> ascls = Arrays.asList(str);
     System.out.print("8) Sorted string in ascending orders"+"=="+ascls);
  	 System.out.println();
     
     Arrays.sort(str,Collections.reverseOrder());
     List<String> dscls = Arrays.asList(str);
    /* for(String sort:str) {
    	System.out.print("Sorted string in descending orders"+"=="+sort); 
    	System.out.println();
     }*/
     System.out.print("9) Sorted string in descending orders"+"=="+dscls); 
 	 System.out.println();
 //To Print in ascending and descending orders  
     
		
List<Products> prod = //new ArrayList<Products>();

Arrays.asList(new Products(3,"Lenovo",10000f),
		new Products(2,"Dell",15000f),
		new Products(1,"Sony",25000f),
		new Products(4,"HP",35000f),
		new Products(5,"Dell",50000f));	

List<Object> prod4 = Arrays.asList(7,8,9,10,11,12);
System.out.println("Arrays aS List ::"+""+prod4);

List<Object> prod2 = new ArrayList<>();
prod2.add(0,1);  //using index
prod2.add(4);
prod2.add(2);
prod2.add(5);
prod2.add(4);
prod2.add(1,3);   //using index
System.out.println("10) Index of ::"+""+prod2.indexOf(4));
System.out.println("11) Index of ::"+""+prod2.lastIndexOf(4));


Object[] StringArr = new Object[prod2.size()]; //Creating an Object Array.
prod2.toArray(StringArr); //Changing ArrayList to Array.
for(Object StringArry:StringArr) {
	System.out.println("12) String Array from ArrayList::"+""+StringArry);
}

List<Object> prod3 = new ArrayList<>();
prod3.add(6);
prod3.add("Hello");
prod3.addAll(prod2);

System.out.println("13) Object in Arrays ::"+""+prod3);
//System.out.println("Object in Arrays ::"+""+prod3);

/*List<Products> prod2 = new ArrayList<Products>();

prod2.add(new Products(1,"Lenovo",10000f));
prod2.add(new Products(2,"Dell",15000f));
prod2.add(new Products(3,"Sony",25000f));
prod2.add(new Products(4,"HP",35000f));
prod2.add(new Products(5,"Dell",50000f));*/

//1.Using Iterator
Iterator<Products> iter = prod.iterator();
     while(iter.hasNext()){
       	Products pr = iter.next();
       	System.out.println("14) Using Iterator::"+pr.id+" "+pr.name+" "+pr.price);
       }

//2. Using Iterator inside for-Loop without using While Loop
for(Iterator<Products> itera = prod.iterator();
		itera.hasNext();
   ) {
          	Products pr = itera.next();
        	System.out.println("15) Without using While Loop::"+pr.id+" "+pr.name+" "+pr.price);
     }
//3.Using Lambda Expression         
prod.forEach(pr->System.out.println("16) Lambda Expression::"+pr.id+" "+pr.name+" "+pr.price));       

//4. Using for Loop
for(int i=0;i<prod.size();i++) {
	//if(!prod.isEmpty()) {
	    Products pr = prod.get(i);
		System.out.println("17) Products using for Loop::"+""+pr.id+" "+pr.name+" "+pr.price);	
	//}
} 
	//prod.forEach(p->System.out.println(p.price));

	/* for (int i = 1; i < prod.size(); i++) {
            Products a1 = prod.get(i);   //System.out.println(a1.id);
            Products a2 = prod.get(i-1); //System.out.println(a2.id);
            if (a1.equals(a2)) {
            	prod.remove(a1);
            }
        }*/ 
	

	/*prod.forEach(p->System.out.print("List after short"+","+p.name));
	System.out.println();*/
	// prod.forEach(p->System.out.println("List after short"+","+p.price));
	
	
 /* prod.stream()				                       
.forEach(p->System.out.print(p.getName()));
	*/
 
Set<String> mapresult = prod.stream()
			                        .filter(p->p.name!=null)        //filter based on Predicate
			                       // .map(p->p.name)                 //fetch
			                        .map(Products::getName)         // fetch but getter, setter required
			                       // .collect(Collectors.toSet());   // collect  //Collectors is a final class that extends Object class.
                                    .collect(toCollection(HashSet::new));

Products maxresult = prod.stream()
                         .max((p1,p2)->p1.price>p2.price?1:-1).get();
System.out.println("18) Maximum Map New Result"+"=="+ maxresult.price); 

Set<String> pss= prod.stream()
                    .filter(t->t.name!=null) //==t.name or !=null
                    .map(t->t.name)
                    .collect(Collectors.toSet());

System.out.println("18A)"+""+pss);

 
Set<Float> mapresult1 = prod.stream()
			                        .filter(p->p.price!=0.0f)
			                        .map(p->p.price)
			                        .collect(Collectors.toSet());


float floatprice = prod.stream()
                       .map(p->p.price)
                       .reduce(0.0f,Float::sum);
System.out.println("19) Sum of Price"+"=="+floatprice);

//Java 17

List<String> numbers = Arrays.asList("1", "2", "3", "4", "5");
int mapToInt = numbers.stream()
                      .mapToInt(Integer::parseInt)  //mapToLong,mapToDouble from Java 17
                      .sum();
System.out.println("String array to Integer parsed in Java17 is"+"="+mapToInt);

Optional<String> optional1 = Optional.of("Hello");
System.out.println(optional1.get());

Optional<String> opt = Optional.ofNullable(null);
System.out.println(opt.isPresent());

optional1 = Optional.of("Hello");
optional1.ifPresent(value->System.out.println(value.length()));
Optional<String> filtered = optional1.filter(value->value.length() > 6);
System.out.println(filtered.isPresent());

//Java 17

double sumresult = prod.stream()
                       .collect(Collectors.summingDouble(p->p.price));                        
System.out.println("20) Sum of Price"+"=="+sumresult);

double average = prod.stream().collect(averagingDouble(p->p.price));  //Products::getPrice
System.out.println("21) Averaging Double"+"=="+average);

  sumresult =   prod.stream()
                    .collect(Collectors.averagingDouble(p->p.price));
System.out.println("22) Avgresult"+"=="+sumresult);
System.out.println();
prod.forEach(p->System.out.println("22A ) Avgresult data"+"="+p.name+" "+p.price));
System.out.println();
prod.stream().forEach(p->System.out.println("22B ) Avgresult data"+"="+p.name+" "+p.price));
System.out.println();

long count = prod.stream()   
			      .filter(p->p.price>10000)
			      .collect(Collectors.counting()); //<<OR>>
			      //.count();
System.out.println("23) Count of Price lists greater than 10000"+"="+count);

                       
Map<Integer, String> mapresult2= prod.stream()
                                     .collect(Collectors.toMap(p->p.id,p->p.name));
//forEach is a default method in Iterable interface.
mapresult2.entrySet().forEach(p->System.out.print("24) Hello"+p.getKey()+"="+p.getValue()));
System.out.println();
mapresult2.entrySet().stream().forEachOrdered(p->System.out.print("25) Hello"+p.getKey()+"="+p.getValue()));
System.out.println();

/*prod.stream()
.collect(Collectors.toMap(p->p.id,p->p.name));
*/
/*prod.stream()
.forEach(p->System.out.println(p.name));*/

//prod.forEach(p->System.out.println(p.price));
Set<String> mySet = new HashSet<>();
 
mapresult2 = mapresult2.entrySet()
						.stream()
						.filter(e->mySet.add(e.getValue()))
						.collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
System.out.printf("26) After: %s%n", mapresult2); 

/*Set<Entry<Integer, String>> ent = mapresult2.entrySet();
ent.forEach(p->System.out.println("SET ENTRY::"+p.getKey()+ "  "+ p.getValue()));  */

//<OR the below>

for(Iterator<?> itr = mapresult2.entrySet().iterator();
		     itr.hasNext();
   )
{  
@SuppressWarnings("rawtypes")
Map.Entry mapentry = (Map.Entry) itr.next();
String result = (String) mapentry.getValue();
       if(!mySet.contains(result)) {
            mySet.add(result);
    	   // itr.remove();
     }
}

//sorted hashMap keys

//mapresult2.entrySet().forEach(e->System.out.println(e.getKey()));

//Map<Integer,String> ent = new TreeMap<Integer, String>(mapresult2);

/*for(Map.Entry<Integer,String> entr:ent.entrySet()) {
for(Map.Entry<Integer, String> entr:ent.entrySet()) {
	System.out.println("Entr"+" "+entr.getKey());
	
}

/*System.out.println("map before removing values: " + mapresult2);
//mapresult2.entrySet().removeIf((e1,e2) -> e1.getValue()>(e2.getValue()? 1: -1).get();
mapresult2.entrySet().removeIf(e -> e.getValue().compareTo(String.valueOf(e.getValue())) > 0);
System.out.println("map after removing values: " + mapresult2);
*/

/*Set<String> mySet = new HashSet<String>();

for (Iterator itr = mapresult2.entrySet().iterator(); itr.hasNext();)
{
    Map.Entry<String, String> entrySet = (Map.Entry) itr.next();

    String value = entrySet.getValue();

    if (!mySet.add(value))
    {
        itr.remove();               
    }
}*/

		
	System.out.println("27) Map Results"+mapresult);
	System.out.println("28) Map Results 1"+mapresult1);
	System.out.println("29) Map Results 2"+mapresult2);
	
	double s = calculateAverage(mapresult1);
	System.out.println("30) Average Result"+"=="+s);
	
	String s2 = "Java";
	System.out.print("31) Printing after removal of Duplicate characters in String::"+"=="+doSorted(s2));
	System.out.println();
	
	String s3="Hello Jayakumar";	
	String[] s4 = s3.split(" ");       //String[] s4 = s3.split("");--> Without Space-->this will reverse the letters not the words.(r a m u k a y a J   o l l e H)
	
	String[] s5 = s3.split(" "); 
	String s7="";
	Arrays.sort(s5,Collections.reverseOrder());
	for(String s6:s5) {
		System.out.print(s6+" ");
		s7+=s6+" ";
	}
	System.out.print("32) Collections.reverseOrder"+"::"+s7+" ");
	System.out.println();
	// <<OR>>
	reverseString(s4);       //String Reverse Order Method.
	System.out.println();
	
	int[]arry= {1,2,3,4,5,6,7,8,9,11};
	//LambdaStream lambdaStream = new LambdaStream();
	int calMissing = missingnumber(arry,11);
	System.out.printf("33) Missing number in array %s is %d %n ", Arrays.toString(arry),calMissing);
	
	int[] codes = new int[6];
	codes [1] = 10;
	 codes [2] = 20;
	 codes [3] = 30;
	 codes [4] = 40;
	 codes [5] = 50;
	 for (int i = 1; i < codes.length; i++)	{
	 System.out.printf("34) Code Length in an array %s %n ",codes[i]+"");}	
	 
	 
     List<String[]> lstStr = Arrays.asList(new String[] {"Hello"},new String[]{"This is"},new String[]{"Jayakumar"});
	 String concatedString = lstStr.stream().flatMap(Arrays::stream).collect(Collectors.joining(","));
	 System.out.println("34A) String Concatenation"+" == "+concatedString);
	 
     List<String> lstStr1 = Arrays.asList("Hello","This is","Jayakumar");
	 String concatedString1 = lstStr1.stream().collect(Collectors.joining(","));
     System.out.println("34B) String Concatenation"+" == "+concatedString1);
	 
	 
	 Stream<String> words = Stream.of("Hello","Thisis","Jayakumar");
	 Map<String,Long> letterCount =  words.map(t->t.split("")) 
	                                           .flatMap(Arrays::stream)
	                                           .collect(groupingBy(identity(),counting()));

	 letterCount.entrySet().forEach(t->System.out.print(" "+t.getKey()+"="+t.getValue()));
	 System.out.println(" ");
	 System.out.println("35) Count of Letters =="+""+letterCount);
	 
	 
	 List<String> words1 = Arrays.asList("Hello","Thisis","Jayakumar");
     Map<String, Long> wordCounts = words1.stream()
					           .flatMap(t -> Stream.of(t.split(",")))
					           .collect(Collectors.groupingBy(identity(),counting()));
					           //.count();  //If used only for returning ex.Long count=6. etc.,
  
     wordCounts.entrySet().forEach(t->System.out.print(" "+t.getKey()+"="+t.getValue()));
	 System.out.println(" ");
	 System.out.println("35A) Count of Words=="+""+wordCounts);
	 
	 
	 String[] arrayOfWords = {"Java", "Magazine"};  //Prints Stream Of words [Java, Magazine]
	 //Stream<String> streamOfwords1 = Stream.of(arrayOfWords1);  //we can use any of the below
	 Stream<String> streamOfwords = Arrays.stream(arrayOfWords);
	 List<String> streamOfwordss =  streamOfwords
			                                 .flatMap(t->Stream.of(t.split(" ")))
			                                 //.peek(System.out::println)
                                             .collect(Collectors.toList());  //<OR> .collect(toList()) due to static import;
	 System.out.println("35B) Stream Of words"+" "+streamOfwordss);
	 
	 
	 String[] arrayOfLetters = {"Java", "Magazine"};    //Prints Stream Of letters [J, a, v, a, M, a, g, a, z, i, n, e]
	 //Stream<String> streamOfLetters = Stream.of(arrayOfLetters);  //we can use any of the below
	 Stream<String> streamOfLetters = Arrays.stream(arrayOfLetters);
	 List<String> streamOfLetterss =  streamOfLetters
			                                 .map(t->t.split(""))      // this will directly used in flatMap also, map is not required.
                                             .flatMap(Arrays::stream) //we can use this too:: Stream.of
                                             .collect(Collectors.toList());  //<OR> .collect(toList()) due to static import;
	 System.out.println("36) Stream Of words"+" "+streamOfLetterss);
	 
  
//Printing to Upper-case	 
String upp ="abcdefgh";
Stream.of(upp).map(String::toUpperCase).forEach(e->System.out.println("36A)String UpperCase"+":: "+e));
	 
	 
//Printing to Odd numbers in LEFT and Even numbers in RIGHT	 
int[] array = {2,3,4,5,6,7,8,9};
int[] OddEvenNumb =Arrays.stream(array).boxed().sorted((a,b)->b%2-a%2).mapToInt(Integer::intValue).toArray(); //int[] array = {2,3,4,5,6,7,8,9};	
System.out.println("36B) Printing OddNum in LEFT and EvenNum in RIGHT"+": "+Arrays.toString(OddEvenNumb));


//Another way of Printing to Odd numbers in LEFT and Even numbers in RIGHT
List<Integer> OddNumbers = Arrays.asList(2,3,4,5,6,7,8,9);  //we can use List.of()
List<Integer> OddNumb = OddNumbers.stream().filter(n->n%2!=0).collect(Collectors.toList());
                        OddNumbers.stream().filter(n->n%2==0).collect(Collectors.toCollection(()-> OddNumb));
System.out.println("36C) Another way of Printing OddNum in LEFT and EvenNum in RIGHT"+": "+OddNumb);

//Alternate way of Printing to Odd numbers in LEFT and Even numbers in RIGHT
int[] OddNumbs =OddNumbers.stream().sorted((a,b)->b%2-a%2).mapToInt(Integer::intValue).toArray(); //List<Integer> OddNumbers = Arrays.asList(2,3,4,5,6,7,8,9);
System.out.println("36D) Alternate way of Printing OddNum in LEFT and EvenNum in RIGHT"+": "+Arrays.toString(OddNumbs));


//Arrange number such way negative number should be left and positive number should on right side
int[] arrays= {-2,-5,-8,-1,-4,3,6,2,8,9};
int temp=0;
for(int i=0;i<arrays.length-1;i++) {
	
	for(int j=i+1;j<arrays.length;j++) {
		
		if(arrays[i]>arrays[j]) {			
			temp=arrays[i];
			arrays[i]=arrays[j];
			arrays[j]=temp;
		    }	
	     }
      } for(int i=0; i<arrays.length;i++) {	
            System.out.println("36E) Arrange number"+":: "+arrays[i]);	 
        }
 
//Alternate way -- Arrange number such way negative number should be in left and positive number should in right side
int[] OddEvenNumbs =Arrays.stream(arrays).boxed().sorted((a,b)->a-b).mapToInt(Integer::intValue).toArray();	
System.out.println("36F) Another way - Arrange number"+": "+Arrays.toString(OddEvenNumbs));


	 
//Balanced Brackets	--Dry-Run-Without extra space 
String balancedBracket = "((())";	   //Considering only one type "()"
String balancedBrackets = "({[]})";	   // Any type
String resu = CheckBalancedBracket(balancedBrackets);	 
System.out.println("36G) Balanced Brackets"+":: "+resu); 	

//Alternate way of //Balanced Brackets	--Dry-Run-Without extra space
System.out.println("36H) Alternate way of Balanced Brackets"+":: "+(isValid(balancedBracket)?"Valid":"Not Valid"));  //true:false

System.out.println("36I) Multi Balanced Brackets"+":: "+(isVal(balancedBrackets)?"Valid":"Not Valid")); //true:false


//test
String[] str3 = {"ABCD","EFGH"};

String ss="";
for(int i=str3.length-1;i>=0;i--) {
	
	System.out.println(str3[i]+"");
	ss+=str3[i].toLowerCase()+" ";
}System.out.println(ss);

String ss1="";
for(String s51: str3) {
	System.out.println(s51);
	ss1+=s51+" ";
}System.out.println(ss1.toLowerCase());


String[] seats= {"Reverse","String"};

String[] seat=Stream.of(seats).map(t->new StringBuffer(t).reverse().toString()).toArray(String[]::new);
String sp=Stream.of(seat).collect(Collectors.joining(","));
System.out.println(sp);

Stream.of(sp).forEach(sd->System.out.println(sd));

String fact= "Reverse String";
String[] facts=Stream.of(fact).map(r->new StringBuffer(r).reverse().toString()).toArray(String[]::new);
String spa=Stream.of(facts).collect(Collectors.joining(""));
Stream.of(spa).forEach(w->System.out.println(w));
/*facts
 * List<String> seat=
 * Arrays.stream(seats).collect(Collectors.toList()).reversed();
 * //forEach(seat->System.out.println("Enhanced For loop alternate"+" "+seat));
 * String seatt=seat.stream().collect(Collectors.joining(""));
 * System.out.println(seat);
 */


} // Static main method closed


//Alternate way of //Balanced Brackets	 
public static boolean isValid(String input){
    return Stream.of(input.split(""))
                     .map(c->c.equals("(")?1:c.equals(")")?-1:0)   //Considering only one type "()"
                     .reduce(0,(a,b)->a+b)>=0 && input.chars() //==0 or >=0
                     .filter(c->c=='('||c==')')
                     .count()%2==0;           
  }


public static boolean isVal(String input){	    //Considering multi-types "({[])";
	return Stream.of(input.split(""))
			      .map(a->{
			    	  if(a.equals("("))return 1;
			    	  else if(a.equals(")"))return -1;  
			    	  if(a.equals("["))return 2;			    	  
			    	  else if(a.equals("]"))return -2;
			    	  if(a.equals("{"))return 3;
			    	  else if(a.equals("}"))return -3;
			    	  else return 0;
			      })			
			      .reduce(0,(a,b)->a+b)==0 && input.chars()  //==0 or >=0
			      .filter(c->c==('(')||c==(')')||c==('[')||c==(']')||c==('{')||c==('}'))
			      .count()%2==0;	 	
	
}


public static String CheckBalancedBracket(String balancedBrackets) {  //Alternate ways for Balanced Multi-Brackets	--Dry-Run-Without extra space 

	while (true) {
   
		int originalLength = balancedBrackets.length();

		balancedBrackets = balancedBrackets.replace("[]", ""); 
		balancedBrackets = balancedBrackets.replace("{}", "");
		balancedBrackets = balancedBrackets.replace("()", "");

		int newLength = balancedBrackets.length();

		if (newLength == originalLength)
			break;
	}
	return balancedBrackets.length() == 0 ? "Balanced Multi Brackets" : "Not Balanced Multi Brackets";
}


private static double calculateAverage(Set<Float> mapresult1) {
	  Float sum = 0.0f;
	  if(!mapresult1.isEmpty()) {
	    for (Float res : mapresult1) {
	        sum += res;
	    }
	   // return sum.doubleValue() / avg.size();
	  }
	  return sum / mapresult1.size();
	}

//Remove the duplicate characters in a string

public static String doSorted(final String s1) {
	
	//s1 = "Hello"; // this can't be declared if it's final keyword above.
	
	StringBuffer sf = new StringBuffer();
	Set <Character> ss = new HashSet<>();

	for(int i=0; i<s1.length();i++) {	
		Character cc = s1.charAt(i);
		//System.out.println(cc);
		if(!ss.contains(cc)) {
			ss.add(cc);
			sf.append(cc);	
		}
		
	}
	return sf.toString(); 
}
//Remove the duplicate characters in a string


//Reverse of the string::
public static void reverseString(String[] s4) {

for(int i=0;i<s4.length;i++) {
	System.out.print(s4[i]+" ");
 }System.out.println();
  
  for(int i=s4.length-1;i>=0;i--) {
	  System.out.print(s4[i]+" ");
	 // System.out.print("");
  } //return Arrays.toString(s2);
}
//Reverse of the string::

//To find the Missing numbers in a string

public static int missingnumber(int[] arry,int n){	
	int actual=0;
	int expected = (n*(n+1)/2);
	for(int i :arry){		
		actual+=i;
	} return expected-actual;
	
}
//To find the Missing numbers in a string	

} //Main class closed



//Synechron test - Using Java8 Stream
class classroomSeat {
  public static void main(String[] args) {
      char[][] seats = {
              {'#', '.', '.', '.'},
              {'.', '#', '.', '.'},
              {'.', '.', '.', '.'},
              {'.', '.', '.', '#'}
      };

      System.out.println("Broken seats:");
      printBrokenSeats(seats);

      System.out.println("Available seats:");
      printAvailableSeats(seats);

      System.out.println("Total available seats:");
      System.out.println(countAvailableSeats(seats));
  }

  private static void printBrokenSeats(char[][] seats) {
      IntStream.range(0, seats.length)
              .forEach(i -> IntStream.range(0, seats[i].length)
                      .filter(j -> seats[i][j] == '#')
                      .forEach(j -> System.out.println("Row " + (i + 1) + ", Column " + (j + 1))));
  }

  private static void printAvailableSeats(char[][] seats) {
      IntStream.range(0, seats.length)
              .forEach(i -> IntStream.range(0, seats[i].length)
                      .filter(j -> seats[i][j] == '.')
                      .forEach(j -> System.out.println("Row " + (i + 1) + ", Column " + (j + 1))));
  }

  private static long countAvailableSeats(char[][] seats) {
      return IntStream.range(0, seats.length)
              .flatMap(i -> IntStream.range(0, seats[i].length)
                      .filter(j -> seats[i][j] == '.'))
              .count();
  }
}



//Synechron test
class ClassroomSeats {
  public static void main(String[] args) {
      char[][] seats = {
              {'#', '.', '.', '.'},
              {'.', '#', '.', '.'},
              {'.', '.', '.', '.'},
              {'.', '.', '.', '#'}
      };

      System.out.println("Broken seats:");
      printBrokenSeats(seats);

      System.out.println("Available seats:");
      printAvailableSeats(seats);

      System.out.println("Total available seats:");
      System.out.println(countAvailableSeats(seats));
  }

  private static void printBrokenSeats(char[][] seats) {
      for (int i = 0; i < seats.length; i++) {
          for (int j = 0; j < seats[i].length; j++) {
              if (seats[i][j] == '#') {
                  System.out.println("Row " + (i + 1) + ", Column " + (j + 1));
              }
          }
      }
  }

  private static void printAvailableSeats(char[][] seats) {
      for (int i = 0; i < seats.length; i++) {
          for (int j = 0; j < seats[i].length; j++) {
              if (seats[i][j] == '.') {
                  System.out.println("Row " + (i + 1) + ", Column " + (j + 1));
              }
          }
      }
  }

  private static int countAvailableSeats(char[][] seats) {
      int count = 0;
      for (char[] row : seats) {
          for (char seat : row) {
              if (seat == '.') {
                  count++;
              }
          }
      }
      return count;
  }
}




class classroomAvailableSeat {
	  public static void main(String[] args) {
	      char[][] seats = {
	              {'#', '.', '.', '.'},
	              {'.', '#', '.', '.'},
	              {'.', '.', '.', '.'},
	              {'.', '.', '.', '#'}
	      };

	      System.out.println("Broken seats:");
	      System.out.println(printBrokenSeats(seats));

	      System.out.println("Available seats:");
	      System.out.println(printAvailableSeats(seats));

	      System.out.println("Total available seats:");
	      System.out.println(countAvailableSeats(seats));
	  }

	  private static long printBrokenSeats(char[][] seats) {
		  
		  return IntStream.range(0, seats.length)
		           .flatMap(i-> IntStream.range(0, seats[i].length)
		           .filter(j -> seats[i][j]=='#')).count();
		          // .forEach(j -> System.out.println("Rows"+(i+1)+", Columns"+(j+1))));
	  }
	  

	  private static long printAvailableSeats(char[][] seats) {
	     return IntStream.range(0, seats.length)
	              .flatMap(i -> IntStream.range(0, seats[i].length)
	                      .filter(j -> seats[i][j] == '.')).count();
	                     // .forEach(j -> System.out.println("Row " + (i + 1) + ", Column " + (j + 1))));
	  }

	  private static long countAvailableSeats(char[][] seats) {
	      return IntStream.range(0, seats.length)
	              .flatMap(i -> IntStream.range(0, seats[i].length)
	                      .filter(j -> seats[i][j] == '.'))
	              .count();
	  }
	}


//test practice
 interface Rectangle {
  default void draw() {
        System.out.println("Drawing rectangle");
    }
}

 interface Circle {
    static void draw() {
        System.out.println("Drawing circle");
    }
}

class ShapeAdapter implements Circle {
//   private Circle circle;
//    public ShapeAdapter(Circle circle) {
//      circle = circle;
//    }
//	
//	  public void draw() { 
//		  circle.draw(); 
//		  }
	 
    
    public static void main(String[] args) {
    	//ShapeAdapter shapeAdapter = new ShapeAdapter();
    	Circle.draw();
       
    }
}





//Java 21+
class Loantest {	
	static
	{ 
	    main(new String[] { "Hello" }); 
	} 
	public static void main(String[] args) 
	{ 
	    System.out.println("Hii"); 
	} 
	
	String displayMessageforLoan(Loan loan) {
		
		return switch(loan) {
		
		case securedLoan sl->"Secured Loan";		
		
		case insecuredLoan (var interest)->"In-Secured Loan";
		
		default -> throw new IllegalArgumentException("Unexpected value: " + loan); // this is because of sealed or non-sealed class below, else not required
		};
		
	}
		
	}

//Java 21+
sealed interface Loan permits securedLoan,insecuredLoan,noTypeLoan,inSecuredLoan{}

final class securedLoan implements Loan{}

non-sealed class noTypeLoan implements Loan {}  // this should have either sealed or non-sealed super-class/super-interface.
final class typeLoan extends noTypeLoan {}   // can have final or non-final

record insecuredLoan(float interest) implements Loan{}

sealed class inSecuredLoan implements Loan permits noLoan {}  //For this, Sub-class should be defined as final,sealed,non-sealed.
final class noLoan extends inSecuredLoan{}

sealed class x permits y {}  //For this, Sub-class should be defined as final,sealed,non-sealed.
final class y extends x{}






