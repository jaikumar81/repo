package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Sorting {
	
	public static void main(String args[]) {
		
		int[] arr = {8,7,6,5,4,3,2,1,5,4,3,2,8};
		int[] arr2  = doSorting(arr);
		
		//Arrays.sort(arr);
		Set<Integer> st = new TreeSet<>(
				(Integer a, Integer b)-> {
		   return b.compareTo(a);		
		});
		
		for(int i:arr2) {
			if(!st.contains(i)) 
				st.add(i);			
		}System.out.println(Arrays.toString(arr)+"== "+st);
		
		//Arrays.asList(st);
		List<Integer> list = new ArrayList<Integer>(st);
		list.sort(Collections.reverseOrder());
		for(int sq:list) {
			System.out.println(sq);
		}
		
				
		String[] array = {"D","E","A","C","B"};
		String[] arrays = selectionSort(array);
		
	System.out.println(Arrays.toString(arrays));
		
	//<<OR>>
		for(String i:arrays) {
			//System.out.print(Arrays.toString(arrays));    //[A, B, C, D, E],[A, B, C, D, E],[A, B, C, D, E],[A, B, C, D, E],[A, B, C, D, E],
			System.out.print(i+" ");
			System.out.print("");
		}
		
	}

	private static int[] doSorting(int[] arr) {		       //selectionSort(array, size)
		
		for (int i = 0; i < arr.length - 1; i++) {         //repeat (size - 1) times                          
				int index = i;                             //set the first unsorted element as the minimum
			    for (int j = i + 1; j < arr.length; j++)   //for each of the unsorted elements
					if (arr[j] < arr[index])               //if element < currentMinimum
						index = j;                         // set element as new minimum
		 
				int smallnumber = arr[index];                
				arr[index] = arr[i];
				arr[i] = smallnumber;                      //swap minimum with first unsorted position

		   } return arr;                                     //end selectionSort
			
		}
	
	
	
	public static String[] selectionSort(String[] array)
	  {
	    
	    for ( int i=0; i< array.length-1; i++ )
	    {
	      
	         int index = i;
	      for ( int j=i+1; j < array.length; j++ )
	        if ( array[j].compareTo( array[index] ) < 0 ) 
	        	index = j;  

	      // Swap the reference at j with the reference at min 
	      String temp = array[index];
	      array[index] = array[i];
	      array[i] = temp;
	    } return array;
	  }	
		
	}


