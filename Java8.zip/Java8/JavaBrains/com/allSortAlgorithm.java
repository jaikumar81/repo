package com;

import java.util.HashSet;

public class allSortAlgorithm {
	
public static void main(String[] args) {
	   int[] array = { 0,9,8,4,5,6,7,3,2,1,1};
	   SelectionSort(array);
	   bubble_srt(array);
	   doInsertionSort(array);
	   bubbleSort(array);
  }
	
//1.Selection sort algorithm		
public static void SelectionSort(int[] array) {		
		
		for(int i=0; i<array.length-1; i++) {
			int index =i;
		   for(int j=i+1; j<array.length; j++)				
				if (array[j] < array[index])
					index=j;	
			
			int smallnumber = array[index];
			array[index]=array[i];
			array[i]=smallnumber;
			
		} printNumbers(array);
		//return arr;		
		
	}		
//1.Selection sort algorithm	


//2.Bubble Sort algorithm	
 public static void bubble_srt(int[] array) {
      	    
        for(int j = array.length; j>= 0; j--) {        
	    	for(int i = 0; i < array.length - 1; i++) {            	
	    		int index = i + 1;
                if (array[i] > array[index]) {
                   
                	int smallNumber = array[i];
                    array[i] = array[index];
                    array[index] = smallNumber;
                }
            }
           //printNumbers(array);
        } printNumbers(array);
    }
//2.Bubble Sort algorithm 
 
 
//2a.Alternate Bubble Sort Algorithm
public static void bubbleSort(int[] array) {
 
	for(int i = 0; i < array.length - 1; i++) {       
		for (int j = 0; j < array.length - i - 1; j++) {           
			if (array[j] > array[j + 1]) {
				
		        int smallNumber = array[j];
		        array[j] = array[j + 1];
		        array[j + 1] = smallNumber;
             } 
	        }
        }	printNumbers(array);
 }
//2a.Alternate Bubble Sort Algorithm

    
//3.Insertion Sorting Algorithm    
public static void doInsertionSort(int[] array){
		
	    int index;
	    for(int i = 1; i < array.length; i++) {
		    for(int j = i ; j > 0 ; j--){
			    if(array[j] < array[j-1]){
			    	index = array[j];
				    array[j] = array[j-1];
				    array[j-1] = index;
			    }
		    }
	    } printNumbers(array);
	    //return array; 
	}
//3.Insertion Sorting Algorithm  

private static void printNumbers(int[] array) {
	 
  for(int i = 0; i < array.length; i++) {
		  System.out.print(array[i] + ", ");
		  System.out.print("");
      }
       System.out.println("\n");
       
    HashSet<Integer> sst = new HashSet<>();
       for(int x:array) {
       	if(!sst.contains(x)) {
       		sst.add(x);
       	}
       } System.out.println("After Removal of Duplicates::"+" "+sst);
       System.out.println();
    }

}
