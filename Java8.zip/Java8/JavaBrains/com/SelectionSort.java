package com;

public class SelectionSort {
	
	public static int[] arraySort(int[] arr) {		
		
		for(int i=0; i<arr.length-1; i++) 
		{
			int index =i;
		    for(int j=i+1; j<arr.length; j++)				
				if (arr[j] < arr[index])
					index=j;	
			
			int smallnumber = arr[index];
			arr[index]=arr[i];
			arr[i]=smallnumber;
			
		}return arr;		
		
	}
	
	public static void main(String args[]) {
		
		int[] arr = {10,34,2,56,7,67,88,42};	
		//int [] arr3 = {8,6,4,5,3,2,1,7};
	    int[] arr2= arraySort(arr);
	    
	    for(int i : arr2) {	    	
	    	System.out.print(i);
	    	System.out.print(",");
	    }
	}
	
}
