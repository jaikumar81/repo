package com.olam.weather.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.weather.model.WeatherDetailsModel;

public interface WeatherDetailsRepository extends JpaRepository<WeatherDetailsModel, Integer> {

	@Query("select u from #{#entityName} u where u.latitude= :latitude and u.longitude= :longitude")
	public List<WeatherDetailsModel> findbyLatLon(@Param("latitude")double lat, @Param("longitude") double lon);

}
