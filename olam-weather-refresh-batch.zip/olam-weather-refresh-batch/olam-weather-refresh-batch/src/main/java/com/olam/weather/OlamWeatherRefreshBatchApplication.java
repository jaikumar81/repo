package com.olam.weather;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.BeansException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@PropertySource("classpath:weathersyncutill.properties")
@EnableEurekaClient
public class OlamWeatherRefreshBatchApplication {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(OlamWeatherRefreshBatchApplication.class, args);
		 JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
	             .toJobParameters();
		 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		 try {
			jobLauncher.run((Job)context.getBean("weatherDump"), jobParameters);
		} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
				| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
			//LOG.error("error while running batch",e);
		}
	}
}
