package com.olam.weather.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ApplicationConfiguration {
	
	@Autowired
	Environment env;
	
	@Bean
	public RestTemplate generateRestTemplate() {
		
		SimpleClientHttpRequestFactory requestFactory =new  SimpleClientHttpRequestFactory();
		
		return new RestTemplate(requestFactory);
	}
	
	
	@Bean
	@Primary
	//@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource generatePrimaryDataSource() {
		
		return DataSourceBuilder
		        .create()
		        .username(env.getProperty("spring.datasource.username"))
		  		.password(env.getProperty("spring.datasource.password"))
		  		.url(env.getProperty("spring.datasource.url"))
		  		.driverClassName(env.getProperty("spring.datasource.driverClassName"))
		        .build();
	}
	
	@Bean
	@Qualifier("masterDataSource")
	//@ConfigurationProperties(prefix = "master.datasource")
	public DataSource generateSecondaryDataSource() {
		 
		return  DataSourceBuilder
		        .create()
		        .username(env.getProperty("master.datasource.username"))
		  		.password(env.getProperty("master.datasource.password"))
		  		.url(env.getProperty("master.datasource.url"))
		  		.driverClassName(env.getProperty("master.datasource.driverClassName"))
		        .build();
	}

}
