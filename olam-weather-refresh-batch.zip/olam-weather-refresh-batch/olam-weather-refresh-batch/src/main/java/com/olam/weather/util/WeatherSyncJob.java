package com.olam.weather.util;

import java.net.URI;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.olam.weather.model.ForecastDetailsModel;
import com.olam.weather.model.WeatherDetailsModel;
import com.olam.weather.repository.ForecastDetailsRepository;
import com.olam.weather.repository.WeatherDetailsRepository;


@Configuration
@EnableBatchProcessing
public class WeatherSyncJob {

	private static final Logger LOG = LoggerFactory.getLogger(WeatherSyncJob.class);
	@Value("${chunkSize}")
	private int chunkSize;
	@Value("${weatherApikey}")
	private String weatherApikey;
	@Value("${weatherApiUnits}")
	private String weatherApiUnits;
	
	long weatherRecordCount=0;
	
	@Autowired
	WeatherDetailsRepository weatherDetailsrepository;
	
	@Autowired
	ForecastDetailsRepository forecastDetailRepository;
	
	@Autowired
	ApplicationContext context;

	@Autowired
	RestTemplate restTemplate;

	private static final String WEATHER_URL =
			// "http://api.openweathermap.org/data/2.5/weather?q={city},{country}&APPID={key}";
			//"http://api.openweathermap.org/data/2.5/weather?lat={Latitude}&lon={Longitude}&APPID={key}";
	"https://api.openweathermap.org/data/2.5/weather?lat={Latitude}&lon={Longitude}&APPID={key}&units={weatherApiUnits}";
	
	private static final String FORECAST_URL="http://api.openweathermap.org/data/2.5/forecast?lat={Latitude}&lon={Longitude}&APPID={key}&units={weatherApiUnits}";

	@Autowired
	DataSource dataSource;
	
	@Autowired
	DataSource masterDataSource;
	
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	@Value("${deleteDump}")
	private String deleteDump;
	@Value("${queryfetchLocation}")
	private String queryfetchLocation;
	@Value("${queryfetchForeCastLocation}")
	private String queryfetchForeCastLocation;
	@Value("${weatherFeedInsert}")
	private String weatherFeedInsert;
	@Value("${talukLatLongQuery}")
	String talukLatLongQuery;
	@Value("${gridSize}")
	int partitionGridSize;
	
	@Bean
	public Job weatherDump() {

		return jobBuilderFactory.get("weatherDump").listener(new JobExecutionListener() {
			
			@Override
			public void beforeJob(JobExecution jobExecution) {
				weatherRecordCount=weatherDetailsrepository.count();
				
			}
			
			@Override
			public void afterJob(JobExecution jobExecution) {
				// TODO Auto-generated method stub
				
			}
		}).start(weatherSyncStep()).build();

	}
	@Bean
	public Job weatherTalukSync() {

		return jobBuilderFactory.get("weatherTalukSync").incrementer(new RunIdIncrementer()).start(weatherSyncRefreshStep()).build();

	}
	@Bean
	public Job forecastTalukSync() {

		return jobBuilderFactory.get("forecastTalukSync").incrementer(new RunIdIncrementer()).start(forecastSyncRefreshStep()).build();

	}
	@Bean
	public Job forecastDump() {

		return jobBuilderFactory.get("forecastDump").flow(forecastSyncStep()).build().build();

	}	

	@Bean
	public Step weatherSyncStep() {

		return stepBuilderFactory.get("weatherSyncStep").<WeatherDetailsModel, WeatherDetailsModel>chunk(chunkSize)
				.reader(locationDbReader()).processor(locationDBDetailProcessor()).writer(weatherDetailWriter())
				.build();
	}
	
	@Bean
	public Step forecastSyncStep() {

		return stepBuilderFactory.get("forecastSyncStep").<ForecastDetailsModel, ForecastDetailsModel>chunk(chunkSize)
				.reader(locationForecastDbReader()).processor(locationForecastProcessor()).writer(foreCastDetailWriter()).build();
	}
@Bean
@StepScope
	public ItemProcessor<? super ForecastDetailsModel, ? extends ForecastDetailsModel> locationForecastProcessor() {
		// TODO Auto-generated method stub
		return new ItemProcessor<ForecastDetailsModel, ForecastDetailsModel>() {
			
			@Override
			public ForecastDetailsModel process(ForecastDetailsModel item) throws Exception {

				URI url = new UriTemplate(FORECAST_URL).expand(item.getLatitude(), item.getLongitude(), weatherApikey,weatherApiUnits);
				RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
				ResponseEntity<String> response = restTemplate.exchange(entity, String.class);
				String str =StringUtils.stripAccents( response.getBody());
				item.setWeather_feed(str);
				item.setUpdated_at(new Date());
				return item;
			}
		};
	}

	@Bean
	public ItemProcessor<WeatherDetailsModel, WeatherDetailsModel> locationDBDetailProcessor() {
		
		return new ItemProcessor<WeatherDetailsModel, WeatherDetailsModel>() {
			
			@Override
			public WeatherDetailsModel process(WeatherDetailsModel itemDB) throws Exception {

				URI url = new UriTemplate(WEATHER_URL).expand(itemDB.getLatitude(), itemDB.getLongitude(), weatherApikey,weatherApiUnits);
				RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
				ResponseEntity<String> response = restTemplate.exchange(entity, String.class);
				String str = StringUtils.stripAccents(response.getBody());
				Optional<WeatherDetailsModel> itemOpt=weatherDetailsrepository.findById(itemDB.getId());
				WeatherDetailsModel item=itemOpt.isPresent()?itemOpt.get():itemDB;
				item.setWeather_feed(str);
				item.setUpdated_at(new Date());
				return item;
			}
		};
	}

	@Bean
	@StepScope
	public JdbcCursorItemReader<WeatherDetailsModel> locationDbReader() {
		JdbcCursorItemReader<WeatherDetailsModel> reader = new JdbcCursorItemReader<WeatherDetailsModel>();
		reader.setDataSource(dataSource);
		/*LOG.info("Limit range---->"+startLimit+","+endLimit);
		if(null!=endLimit&& Long.valueOf(endLimit)>0) {
		reader.setSql(queryfetchLocation
				+"limit "+startLimit+","+endLimit);
		}else {*/
			reader.setSql(queryfetchLocation);
		//}
		reader.setRowMapper(new BeanPropertyRowMapper<WeatherDetailsModel>(WeatherDetailsModel.class));
		
		return reader;
	}

	@Bean
	@StepScope
	public JdbcCursorItemReader<ForecastDetailsModel> locationForecastDbReader() {
		JdbcCursorItemReader<ForecastDetailsModel> reader = new JdbcCursorItemReader<ForecastDetailsModel>();
		reader.setDataSource(dataSource);
		reader.setSql(queryfetchForeCastLocation);
		reader.setRowMapper(new BeanPropertyRowMapper<ForecastDetailsModel>(ForecastDetailsModel.class));
		return reader;
	}

	@Bean
	@StepScope
	public ItemProcessor<String, ForecastDetailsModel> locationForecastDetailProcessor() {
		// TODO Auto-generated method stub
		return new ItemProcessor<String, ForecastDetailsModel>() {

			@Override
			public ForecastDetailsModel process(String arg0) throws Exception {
				ForecastDetailsModel weatherDetails=new ForecastDetailsModel();
				try {
			//	JSONObject obt = new JSONObject(arg0);
				JSONObject coord = new JSONObject(arg0);
				
				//Thread.sleep(100);
				URI url = new UriTemplate(FORECAST_URL).expand(coord.getDouble("lat"), coord.getDouble("lon"),
						weatherApikey);
				RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
				ResponseEntity<String> response = restTemplate.exchange(entity, String.class);
				String str = StringUtils.stripAccents(response.getBody());
				JSONObject json = new JSONObject(str);
				weatherDetails.setLatitude(json.getJSONObject("city").getJSONObject("coord").getDouble("lat"));
				weatherDetails.setLongitude(json.getJSONObject("city").getJSONObject("coord").getDouble("lon"));
				weatherDetails.setWeather_feed(json.toString());
				weatherDetails.setCity(json.getJSONObject("city").has("name")?json.getJSONObject("city").getString("name").replaceAll("[^a-zA-Z]", ""):"");
				weatherDetails.setCountry(json.getJSONObject("city").has("country")?json.getJSONObject("city").getString("country"):"");
				weatherDetails.setCreated_at(new Date());
				weatherDetails.setUpdated_at(new Date());
				}catch(Exception e){
					LOG.error(e.getMessage());
				}
				return weatherDetails;
			}
		};
	}
	
	@Bean
	@StepScope
	public ItemProcessor<String, WeatherDetailsModel> locationWeatherDetailProcessor() {
		// TODO Auto-generated method stub
		return new ItemProcessor<String, WeatherDetailsModel>() {

			@Override
			public WeatherDetailsModel process(String arg0) throws Exception {
				WeatherDetailsModel weatherDetails=new WeatherDetailsModel();
				try {
				
				JSONObject coord =  new JSONObject(arg0);
				LOG.info("request"+coord);
				//Thread.sleep(100);
				URI url = new UriTemplate(WEATHER_URL).expand(coord.getDouble("lat"), coord.getDouble("lon"),
						weatherApikey);
				RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
				ResponseEntity<String> response = restTemplate.exchange(entity, String.class);
				String str = StringUtils.stripAccents(response.getBody());
				LOG.error("Response-->"+str);
				JSONObject json = new JSONObject(str);
				weatherDetails.setLatitude(json.getJSONObject("coord").getDouble("lat"));
				weatherDetails.setLongitude(json.getJSONObject("coord").getDouble("lon"));
				weatherDetails.setWeather_feed(json.toString());
				weatherDetails.setCity(json.has("name")?json.getString("name").replaceAll("[^a-zA-Z]", ""):"");
				weatherDetails.setCountry(json.has("country")?json.getString("country").replaceAll("[^a-zA-Z]", ""):"");
				weatherDetails.setCreated_at(new Date());
				weatherDetails.setUpdated_at(new Date());
				}catch(Exception e){
					LOG.error(e.getMessage());
				}
				return weatherDetails;
			}
		};
	}

	@StepScope
	@Bean
	public ItemWriter<WeatherDetailsModel> weatherDetailWriter() {
		
		return new ItemWriter<WeatherDetailsModel>() {
				int count=0;
			@Override
			public void write(List<? extends WeatherDetailsModel> items) throws Exception {
				for(WeatherDetailsModel item:items) {
					LOG.info(item.getId()+"---->"+item.getCity()+" time---->"+item.getUpdated_at());
				weatherDetailsrepository.save(item);
					
				}
				
			}

		};
	}
	
	@StepScope
	@Bean
	public ItemWriter<ForecastDetailsModel> foreCastDetailWriter() {
		return new ItemWriter<ForecastDetailsModel>() {
				int count=0;
			@Override
			public void write(List<? extends ForecastDetailsModel> items) throws Exception {
				for(ForecastDetailsModel item:items) {
						LOG.info(++count+"---->"+item.getCity());
					if(item.getLatitude()>0) {
						forecastDetailRepository.save(item);
					}
					
				}
				
			}

		};
	}

	@Bean
	public ItemPreparedStatementSetter<String> preparedStatementSetter() {
		return new ItemPreparedStatementSetter<String>() {
			@Override
			public void setValues(String arg0, PreparedStatement arg1) throws SQLException {
				try {

					ObjectMapper objMap = new ObjectMapper();
					JSONObject json = new JSONObject(arg0);
					arg1.setDouble(1, json.getJSONObject("coord").getDouble("lat"));
					arg1.setDouble(2, json.getJSONObject("coord").getDouble("lon"));
					arg1.setObject(3, JsonNodeFactory.instance.textNode(arg0));
					arg1.addBatch();
				} catch (JSONException e) {
					LOG.error("JsonException occured:",e);
				}

			}
		};
	}

	@Bean
		public Step weatherSyncRefreshStep() {

			return stepBuilderFactory.get("dbDumpReader").<String,WeatherDetailsModel>chunk(chunkSize)
					.reader(farmerLocationReader()).processor(locationWeatherDetailProcessor()).writer(weatherDetailWriter()).build();
		}
	@Bean
	public Step forecastSyncRefreshStep() {

		return stepBuilderFactory.get("forecastSyncRefreshStep").<String,ForecastDetailsModel>chunk(chunkSize)
				.reader(farmerLocationReader()).processor(locationForecastDetailProcessor()).writer(foreCastDetailWriter()).build();
	}

		private JdbcCursorItemReader<String> farmerLocationReader() {
			JdbcCursorItemReader<String> reader=new JdbcCursorItemReader<>();
			reader.setDataSource(masterDataSource);
			reader.setSql(talukLatLongQuery);
			reader.setRowMapper(new RowMapper<String>() {
				
				@Override
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					JSONObject obj=	new JSONObject();
				
					try {
						obj.put("lat", Double.valueOf(rs.getString(1)));
						obj.put("lon", Double.valueOf(rs.getString(2)));
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return obj.toString();
				}
			});
			return reader;
		}
	
	@Scheduled(cron="0 0/15 * * * ?")
	public void weatherSyncSchedular() {
	 JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
             .toJobParameters();
	 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
	 try {
		jobLauncher.run((Job)context.getBean("weatherDump"), jobParameters);
	} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
			| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
		LOG.error("error while running batch",e);
	}
	}
	@Scheduled(cron="0 0 0/3 * * ?")
	public void forecastSyncSchedular() {
	 JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
             .toJobParameters();
	 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
	 try {
		jobLauncher.run((Job)context.getBean("forecastDump"), jobParameters);
	} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
			| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
		LOG.error("error while running batch",e);
	}
	}
}
