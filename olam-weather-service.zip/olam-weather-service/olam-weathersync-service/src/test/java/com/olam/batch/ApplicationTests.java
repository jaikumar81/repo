package com.olam.batch;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = Application.class)
@SpringBootTest
public class ApplicationTests {
	private static final Logger LOG = LoggerFactory.getLogger(ApplicationTests.class);

	@Test
	public void contextLoads() {
	}

	private MockMvc mockMvc;
	@Autowired
	private WebApplicationContext wac;

	@Autowired
	DataSource dataSource;

	@Autowired
	ApplicationContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		new JdbcTemplate(dataSource)
				.execute("delete from weather_sync_details where latitude=13.68 and longitude=79.34 ");
		new JdbcTemplate(dataSource)
				.execute("delete from forecast_sync_details where latitude=13.68 and longitude=79.34 ");
	}

	@Test
	public void testWeatherValidRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/details?lat=13.68&&lon=79.34")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.coord").exists());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}

	}

	@Test
	public void testWeatherValidExistingDataRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/details?lat=13.68&&lon=79.34")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.coord").exists());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}

	}

	@Test
	public void testWeatherinvalidRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/details?lat=dfs&&lon=sdgf")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.coord").doesNotExist());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point");
		}
	}

	@Test
	public void testWeatherEmptyParamRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/details").accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.coord").doesNotExist());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point");
		}
	}

	// Test for Weather Forecast
	@Test
	public void testWeatherForecastValidRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/forecast?lat=13.68&&lon=79.34")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.city").exists());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}

	}

	@Test
	public void testWeatherForecastValidExistingDataRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/forecast?lat=13.68&&lon=79.34")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.city").exists());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}

	}

	@Test
	public void testWeatherForecastinvalidRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/forecast?lat=dfs&&lon=sdgf")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$.city").doesNotExist());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point");
		}
	}

	@Test
	public void testWeatherForecastEmptyParamRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/forecast").accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.city").doesNotExist());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point");
		}
	}
}
