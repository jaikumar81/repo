package com.olam.batch.service;

import com.olam.batch.dto.WeatherDetailDTO;

public interface WeatherService {

	public WeatherDetailDTO getWeatherDetails(String lang, double lat, double lon);

	public WeatherDetailDTO getWeatherForecast(double lat, double lon);

}
