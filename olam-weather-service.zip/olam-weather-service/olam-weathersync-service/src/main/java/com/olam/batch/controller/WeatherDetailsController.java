package com.olam.batch.controller;

import java.text.DecimalFormat;
import java.util.List;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.olam.batch.dto.WeatherDetailDTO;
import com.olam.batch.exception.ErrorCode;
import com.olam.batch.model.ForecastDetailsModel;
import com.olam.batch.repository.ForecastDetailsRepository;
import com.olam.batch.repository.WeatherDetailsRepository;
import com.olam.batch.service.WeatherService;
import com.olam.batch.util.OlamFSPConstants;

@RestController
@RequestMapping("/api/v1/")
public class WeatherDetailsController {
	private static final Logger LOG = LoggerFactory.getLogger(WeatherDetailsController.class);

	@Autowired
	WeatherDetailsRepository weatherRepository;

	@Autowired
	ForecastDetailsRepository forecastDetailsRepo;

	@Autowired
	WeatherService weatherService;

	DecimalFormat df = new DecimalFormat("#####.##");

	@RequestMapping(value = "/weather/details", method = RequestMethod.GET)
	public ResponseEntity<String> getWeatherDetails(@RequestHeader(name = "language", required = false) String lang,
			@RequestParam(name = "lat", required = false) String lat,
			@RequestParam(name = "lon", required = false) String lon) {
		JSONObject response = new JSONObject();
		HttpStatus status = null;
		if (!StringUtils.isEmpty(lat) && !StringUtils.isEmpty(lon)) {
			try {
				WeatherDetailDTO dto = new WeatherDetailDTO();
				dto = weatherService.getWeatherDetails(lang, Double.valueOf(df.format(Double.valueOf(lat))),
						Double.valueOf(df.format(Double.valueOf(lon))));
				status = HttpStatus.OK;
				response = new JSONObject(dto.getWeatherFeed().toString());

			} catch (NumberFormatException e) {
				LOG.error("Exception occured:", e);
				status = HttpStatus.BAD_REQUEST;
				response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3002.getErrorCode());
				response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3002.getMessage());
			} catch (Exception e) {
				LOG.error("Exception occured:", e);
				status = HttpStatus.INTERNAL_SERVER_ERROR;
				response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3004.getErrorCode());
				response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3004.getMessage());
			}
		} else {
			status = HttpStatus.BAD_REQUEST;
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3003.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3003.getMessage());
		}
		return new ResponseEntity<String>(response.toString(), status);
	}

	@RequestMapping(value = "/weather/forecast", method = RequestMethod.GET)
	public ResponseEntity<String> getWeatherForecast(@RequestParam(name = "lat", required = false) String lat,
			@RequestParam(name = "lon", required = false) String lon) {

		JSONObject response = new JSONObject();
		HttpStatus status = null;
		if (!StringUtils.isEmpty(lat) && !StringUtils.isEmpty(lon)) {
			try {

				List<ForecastDetailsModel> forecastDet = forecastDetailsRepo.findbyLatLon(
						Double.valueOf(df.format(Double.valueOf(lat))), Double.valueOf(df.format(Double.valueOf(lon))));
				if (null != forecastDet && !forecastDet.isEmpty()) {
					response = new JSONObject(forecastDet.get(0).getWeather_feed().toString());
					status = HttpStatus.OK;
				} else {
					WeatherDetailDTO dto = new WeatherDetailDTO();
					dto = weatherService.getWeatherForecast(Double.valueOf(df.format(Double.valueOf(lat))),
							Double.valueOf(df.format(Double.valueOf(lon))));
					response = new JSONObject(dto.getWeatherFeed().toString());
					status = HttpStatus.OK;
				}
			} catch (NumberFormatException e) {
				LOG.error("Exception occured:", e);
				status = HttpStatus.BAD_REQUEST;
				response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3002.getErrorCode());
				response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3002.getMessage());
			} catch (Exception e) {
				LOG.error("Exception occured:", e);
				status = HttpStatus.INTERNAL_SERVER_ERROR;
				response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3004.getErrorCode());
				response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3004.getMessage());
			}
		} else {
			status = HttpStatus.BAD_REQUEST;
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3003.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3003.getMessage());
		}
		return new ResponseEntity<String>(response.toString(), status);
	}
}
