package com.olam.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@PropertySource("classpath:weathersyncutill.properties")
@EnableEurekaClient
public class Application {
	private static final Logger LOG = LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) {
		ApplicationContext context =SpringApplication.run(Application.class, args);
		

/*		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
	             .toJobParameters();
		 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		 try {
			jobLauncher.run((Job)context.getBean("weatherDump"), jobParameters);
		} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
				| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
			LOG.error("error while running batch",e);
		}*/
		
	}
}
