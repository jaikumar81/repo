package com.olam.batch.exception;

public enum ErrorCode implements ErrorHandle {
	FSP_TS_3001(3001, "Oops!!! Something went wrong, Please contact administrator"),
	
	FSP_TS_3002(3002, "Invalid request parameters"),
	FSP_TS_3003(3003, "Mandatory parameter is missing"),
	FSP_TS_3004(3004, "Internal Error");

	private final int errorCodeNumber;
	private final String message;

	ErrorCode(int errorCodeNumber, String message) {
		this.errorCodeNumber = errorCodeNumber;
		this.message = message;
	}

	@Override
	public int getErrorCode() {
		return this.errorCodeNumber;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

}
