package com.olam.batch.dto;

import java.util.List;
import java.util.Map;

public class WeatherResponseDTO {

	private LatLonDTO coord;
	
	private List<WeatherDTO> weather;

	private String name;

	private MainDTO main;
	

	private WindDTO wind;

	private Map<String, String> rain;

	public Map<String, String> getRain() {
		return rain;
	}

	public void setRain(Map<String, String> rain) {
		this.rain = rain;
	}

	public LatLonDTO getCoord() {
		return coord;
	}

	public void setCoord(LatLonDTO coord) {
		this.coord = coord;
	}

	public List<WeatherDTO> getWeather() {
		return weather;
	}

	public void setWeather(List<WeatherDTO> weather) {
		this.weather = weather;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MainDTO getMain() {
		return main;
	}

	public void setMain(MainDTO main) {
		this.main = main;
	}

	public WindDTO getWind() {
		return wind;
	}

	public void setWind(WindDTO wind) {
		this.wind = wind;
	}

	
}
