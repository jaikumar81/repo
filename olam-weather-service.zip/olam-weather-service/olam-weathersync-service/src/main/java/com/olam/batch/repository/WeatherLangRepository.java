package com.olam.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olam.batch.model.LanguageModel;

public interface WeatherLangRepository extends JpaRepository<LanguageModel, Integer> {

	 public LanguageModel findByName(String name);
}
