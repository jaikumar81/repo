package com.olam.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.olam.batch.model.ForecastDetailsModel;

public interface ForecastDetailsRepository extends JpaRepository<ForecastDetailsModel, Integer> {

	@Query("select u from #{#entityName} u where u.latitude= :latitude and u.longitude= :longitude")
	public List<ForecastDetailsModel> findbyLatLon(@Param("latitude")double lat, @Param("longitude") double lon);

}
