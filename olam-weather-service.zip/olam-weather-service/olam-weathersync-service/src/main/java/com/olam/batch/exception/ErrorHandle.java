package com.olam.batch.exception;

public interface ErrorHandle {

	int getErrorCode();
	String getMessage();
}
