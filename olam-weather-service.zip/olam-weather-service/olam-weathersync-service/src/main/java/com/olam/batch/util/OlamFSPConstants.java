package com.olam.batch.util;

public final class OlamFSPConstants {
	
	private OlamFSPConstants() {
		throw new IllegalStateException("Utility class");
	}

	public static final String ERROR="Error";
	public static final String ERROR_DESC="Error_Description";
	public static final String RESPONSE = "response";
	public static final String STATUS = "status";
	public static final String SUCCESS = "success";
	public static final String EMPTY_STRING = "";
	public static final String TELUGU = "te";
	public static final String HINDI = "hi";
	public static final String NAME = "name";
	public static final String VALUE = "value";
	public static final String RAIN = "RAIN";
	public static final String CURRENT_WEATHER = "Current Weather";
	public static final String HUMIDITY = "HUMIDITY";
	public static final String WIND_SPEED = "WIND SPEED";
	public static final String CLOUDS = "Clouds";
	public static final String CLOUDY = "Cloudy";	

}
