package com.olam.batch.serviceImpl;

import java.net.URI;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.google.gson.Gson;
import com.olam.batch.dto.WeatherDetailDTO;
import com.olam.batch.dto.WeatherResponseDTO;
import com.olam.batch.model.ForecastDetailsModel;
import com.olam.batch.model.LanguageModel;
import com.olam.batch.model.WeatherDetailsModel;
import com.olam.batch.repository.ForecastDetailsRepository;
import com.olam.batch.repository.WeatherDetailsRepository;
import com.olam.batch.repository.WeatherLangRepository;
import com.olam.batch.service.WeatherService;
import com.olam.batch.util.OlamFSPConstants;

@Service
public class WeatherServiceImpl implements WeatherService{

	private static final String WEATHER_URL =
			"https://api.openweathermap.org/data/2.5/weather?lat={Latitude}&lon={Longitude}&APPID={key}&units={weatherApiUnits}";
	private static final String WEATHER_FORECAST_URL =
			"https://api.openweathermap.org/data/2.5/forecast?lat={Latitude}&lon={Longitude}&APPID={key}&units={weatherApiUnits}";

	DecimalFormat tempDF = new DecimalFormat("#####.#");
	
	@Value("${weatherApikey}")
	private String weatherApikey;
	
	@Value("${weatherApiUnits}")
	private String weatherApiUnits;
	
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	WeatherDetailsRepository weatherDetailsRepo;
	
	@Autowired
	WeatherLangRepository langRepo;
	
	@Autowired
	ForecastDetailsRepository forecastDetailsRepo;

	@Override
	public WeatherDetailDTO getWeatherDetails(String lang, double lat, double lon) {
		
		List<WeatherDetailsModel> weatherDetailList = weatherDetailsRepo.findbyLatLon(lat, lon); 
		String str = null;
		WeatherDetailDTO dto=  null;
		if (null != weatherDetailList && !weatherDetailList.isEmpty()) {
			dto=  new WeatherDetailDTO();
			str = weatherDetailList.get(0).getWeather_feed();
			str=StringUtils.stripAccents(str); //replaces accented characters by their unaccented equivalent
			dto= setWeatherValues(lang, lat, lon, str, dto);
		}else {
			dto = getNewLatLonWeatherDetails(lang, lat, lon);
		}
		return dto;
	}
	
	private WeatherDetailDTO getNewLatLonWeatherDetails(String lang, double lat, double lon) {
		WeatherDetailDTO dto=  new WeatherDetailDTO();
	
		URI url = new UriTemplate(WEATHER_URL).expand(lat, lon, weatherApikey,weatherApiUnits);
		RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
		ResponseEntity<String> response = restTemplate.exchange(entity, String.class);
		String str = response.getBody();
		str=StringUtils.stripAccents(str); //replaces accented characters by their unaccented equivalent
		dto= setWeatherValues(lang, lat, lon, str, dto);
		saveWeatherDetails(dto);	
		return dto;
	}

	private void saveWeatherDetails(WeatherDetailDTO dto) {
		
		WeatherDetailsModel model= new WeatherDetailsModel();
		model.setLatitude(dto.getLatitude());
		model.setLongitude(dto.getLongitude());
		model.setWeather_feed(dto.getWeatherFeed().toString());
		model.setCity(dto.getCity());
		model.setCountry(dto.getCountry());
		model.setCreated_at(new Date());
		weatherDetailsRepo.save(model);
		
	}

	private WeatherDetailDTO setWeatherValues(String lang, double lat, double lon, String str, WeatherDetailDTO dto) {

		WeatherResponseDTO res = new WeatherResponseDTO();
		Gson gson = new Gson();
		JSONObject json = new JSONObject(str);
		res = gson.fromJson(str, WeatherResponseDTO.class);
		int mps=0;
		Map<String,String> m = null;
		String curWeather=null;
		
		/* Aug17th Remove unused fields from Json*/
		json.remove("base");
		json.remove("visibility");
		json.remove("id");
		json.remove("clouds");
		json.remove("cod");
		/* Remove unused fields from Json*/
		
		dto.setCoord(res.getCoord());
		dto.setLatitude(lat);
		dto.setLongitude(lon);
		dto.setWeatherFeed(json);
		dto.setCity(res.getName().isEmpty()?OlamFSPConstants.EMPTY_STRING:StringUtils.stripAccents(res.getName()));
		dto.setCountry(json.getJSONObject("sys").has("country")?StringUtils.stripAccents(json.getJSONObject("sys").getString("country")):OlamFSPConstants.EMPTY_STRING);
		
		/* Set temperature to 1decimal */
		double temperature = Double.parseDouble(tempDF.format(Double.parseDouble(res.getMain().getTemp())));
		dto.setTemp(temperature);
		
		LanguageModel humidityLang =  langRepo.findByName(OlamFSPConstants.HUMIDITY);
		LanguageModel windSpeedLang =  langRepo.findByName(OlamFSPConstants.WIND_SPEED);
		LanguageModel currentWeatherLang =  langRepo.findByName(OlamFSPConstants.CURRENT_WEATHER);
		LanguageModel rainLang =  langRepo.findByName(OlamFSPConstants.RAIN);
		String transalatedHumidity = null;
		String transalatedwindSpeed = null;
		String transalatedcurrentWeather = null;
		String transalatedrain = null;
		if(OlamFSPConstants.HINDI.equals(lang) ) {
			transalatedHumidity = humidityLang.getNameHindi();
			transalatedwindSpeed = windSpeedLang.getNameHindi();
			transalatedcurrentWeather = currentWeatherLang.getNameHindi();
			transalatedrain = rainLang.getNameHindi();
		}else if(OlamFSPConstants.TELUGU.equals(lang) ) {
			transalatedHumidity = humidityLang.getNameTelugu();
			transalatedwindSpeed = windSpeedLang.getNameTelugu();
			transalatedcurrentWeather = currentWeatherLang.getNameTelugu();
			transalatedrain = rainLang.getNameTelugu();
		}
		m = new HashMap<String, String>();
		m.put(OlamFSPConstants.NAME,null!=transalatedHumidity?transalatedHumidity:OlamFSPConstants.HUMIDITY);
		m.put(OlamFSPConstants.VALUE, res.getMain().getHumidity());
		dto.setHumidity(m);
		
		m = new HashMap<String, String>();
		mps= (int) Math.round(3.6 * Double.valueOf(res.getWind().getSpeed()));/* conversion to km/h*/
		
		m.put(OlamFSPConstants.NAME, null!=transalatedwindSpeed?transalatedwindSpeed:OlamFSPConstants.WIND_SPEED);
		m.put(OlamFSPConstants.VALUE, String.valueOf(mps));
		dto.setWindspeed(m);	
		
		m = new HashMap<String, String>();
		m.put(OlamFSPConstants.NAME, null!=transalatedcurrentWeather?transalatedcurrentWeather:OlamFSPConstants.CURRENT_WEATHER);
		curWeather=res.getWeather().isEmpty()?OlamFSPConstants.EMPTY_STRING:res.getWeather().get(0).getMain();
		if(curWeather.equals(OlamFSPConstants.CLOUDS)) {
			m.put(OlamFSPConstants.VALUE, OlamFSPConstants.CLOUDY);
		}else {
			m.put(OlamFSPConstants.VALUE, curWeather);
		}
		dto.setCurrentWeather(m);
		
		dto.setDescription(res.getWeather().isEmpty()?OlamFSPConstants.EMPTY_STRING:res.getWeather().get(0).getDescription());

		m = new HashMap<String, String>();
		m.put(OlamFSPConstants.VALUE, json.has(OlamFSPConstants.RAIN.toLowerCase())?res.getRain().get("3h"):"0");
		m.put(OlamFSPConstants.NAME, null!=transalatedrain?transalatedrain:OlamFSPConstants.RAIN);
		dto.setRain(m);
				
		return dto;
	}
	
	
	@Override
	public WeatherDetailDTO getWeatherForecast(double lat, double lon) {

		WeatherDetailDTO dto=  new WeatherDetailDTO();
		URI url = new UriTemplate(WEATHER_FORECAST_URL).expand(lat, lon, weatherApikey,weatherApiUnits);
		RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
		ResponseEntity<String> response = restTemplate.exchange(entity, String.class);
		String str = response.getBody();
		str=StringUtils.stripAccents(str); //replaces accented characters by their unaccented equivalent
		JSONObject json = new JSONObject(str);
		
		dto.setLatitude(json.getJSONObject("city").getJSONObject("coord").getDouble("lat"));
		dto.setLongitude(json.getJSONObject("city").getJSONObject("coord").getDouble("lon"));
		dto.setWeatherFeed(json);
		dto.setCity(json.getJSONObject("city").has("name")?StringUtils.stripAccents(json.getJSONObject("city").getString("name")):"");
		dto.setCountry(json.getJSONObject("city").has("country")?StringUtils.stripAccents(json.getJSONObject("city").getString("country")):"");	
		ForecastDetailsModel model= new ForecastDetailsModel();
		
		model.setLatitude(dto.getLatitude());
		model.setLongitude(dto.getLongitude());
		model.setWeather_feed(dto.getWeatherFeed().toString());
		model.setCity(dto.getCity());
		model.setCountry(dto.getCountry());
		model.setCreated_at(new Date());
		forecastDetailsRepo.save(model);
				
		return dto;
	}

}