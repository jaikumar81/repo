package com.olam.batch.dto;

import java.util.Map;

import org.json.JSONObject;

public class WeatherDetailDTO {

	private LatLonDTO coord;
	private double latitude;
	private double longitude;
	private String city;
	private JSONObject weatherFeed;
	private String country;
	private double temp;
	private Map<String, String> humidity;
	private String description;
	private Map<String, String> currentWeather;
	private Map<String, String> windspeed;
	private Map<String, String> rain;

	public LatLonDTO getCoord() {
		return coord;
	}

	public void setCoord(LatLonDTO coord) {
		this.coord = coord;
	}

	public JSONObject getWeatherFeed() {
		return weatherFeed;
	}

	public void setWeatherFeed(JSONObject string) {
		this.weatherFeed = string;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double getTemp() {
		return temp;
	}

	public void setTemp(double temp) {
		this.temp = temp;
	}

	public Map<String, String> getHumidity() {
		return humidity;
	}

	public void setHumidity(Map<String, String> humidity) {
		this.humidity = humidity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<String, String> getCurrentWeather() {
		return currentWeather;
	}

	public void setCurrentWeather(Map<String, String> currentWeather) {
		this.currentWeather = currentWeather;
	}

	public Map<String, String> getWindspeed() {
		return windspeed;
	}

	public void setWindspeed(Map<String, String> windspeed) {
		this.windspeed = windspeed;
	}

	public Map<String, String> getRain() {
		return rain;
	}

	public void setRain(Map<String, String> rain) {
		this.rain = rain;
	}

}
