package com.olam.marketprice;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = OlamFspMarketPriceApplication.class)
@SpringBootTest
public class OlamFspMarketPriceApplicationTests {


	private static final Logger LOG = LoggerFactory.getLogger(OlamFspMarketPriceApplicationTests.class);

	@Test
	public void contextLoads() {
	}
	private MockMvc mockMvc;
	@Autowired
	private WebApplicationContext wac;
	

	
//	@Autowired
//	DataSource dataSource;
	
	@Autowired
	ApplicationContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void testMarketValidStateRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/marketprice/details?state=ap")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$[0]").exists());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}

	}
	
	@Test
	public void testMarketValidStateDistrictRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/marketprice/details")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$[0]").exists());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}

	}
	@Test
	public void testMarketInvalidRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/marketprice/details?state=asdgf")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$[0]").doesNotExist());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}
	}
	@Test
	public void testMarketEmptyParamRequestService() {
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/weather/details")
					.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$[0]").doesNotExist());
		} catch (Exception e) {
			LOG.error("Error occured while invoking end point", e);
		}
	}
		
}
