package com.olam.marketprice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.olam.marketprice.model.MarketPriceDetails;

@Repository
public interface MarketPriceRepository extends JpaRepository<MarketPriceDetails, Integer> {

	public List<MarketPriceDetails> findByStateAndActive(@Param("state")String state,@Param("active")boolean active);
	
	public MarketPriceDetails findById(@Param("id")int id);
	
	public List<MarketPriceDetails> findByStateAndDistrictAndActive(@Param("state")String state,@Param("district")String district,@Param("active")boolean active);

	@Query(value="select * from market_price where state=:state and district=:district and market_name=:market and category=:category and  commodity_name=:product and variety=:variety and grade=:grade",nativeQuery=true)
	public List<MarketPriceDetails> findProduct(@Param(value="state")String state, @Param(value="district")String district,@Param(value="product") String product,@Param(value="grade")String grade,@Param(value="market")String market,
			@Param(value="category")String category,@Param(value="variety")String variety	);

	public List<MarketPriceDetails> findByActive(@Param("active")boolean active);

}
