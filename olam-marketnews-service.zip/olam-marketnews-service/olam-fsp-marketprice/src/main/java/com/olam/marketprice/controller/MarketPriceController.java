package com.olam.marketprice.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olam.marketprice.exception.ErrorCode;
import com.olam.marketprice.model.MarketPriceDetails;
import com.olam.marketprice.model.MarketPriceReportDetails;
import com.olam.marketprice.service.MarketPriceService;
import com.olam.marketprice.util.OlamFSPConstants;


@RestController
@RequestMapping(value="/marketprice")
public class MarketPriceController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MarketPriceController.class);

	@Autowired
	MarketPriceService marketpriceService;
	
	@Value("${supportedLanguages}")
	String supportedLang;
	
	@RequestMapping(value="/details", method= RequestMethod.GET)
	public ResponseEntity<Object> getMarketPriceDetails(@Param("state") String state,
			@Param("district") String district, @Param("market") String market, @Param("category") String category,
			@Param("variety") String variety,@Param("name") String name,@RequestHeader(name="language",required=false)String lang){

		HttpStatus status = null;
		JSONObject response =new JSONObject() ;
        ObjectMapper mapperObj = new ObjectMapper();
		List<MarketPriceDetails> responseDetails= null;
		if(lang==null||(lang!=null&& supportedLang.contains(lang.toLowerCase()))) {
			try {				
				responseDetails= new ArrayList<MarketPriceDetails>();
				responseDetails=	marketpriceService.getMarketPriceDetailsState(state,district,market,category,variety,name,lang);	
				String resbean=mapperObj.writeValueAsString(responseDetails);
				if(responseDetails.isEmpty()) {
					status= HttpStatus.NOT_FOUND;					
					response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3002.getErrorCode());
					response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3002.getMessage());					
					return new ResponseEntity<Object>(response.toString(), status);
				}
				else {
					status= HttpStatus.OK;
					return new ResponseEntity<Object>(responseDetails, status);
				}
			}catch (Exception e) {
				
				response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3004.getErrorCode());
				response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3004.getMessage());					
				status= HttpStatus.INTERNAL_SERVER_ERROR;
				
				LOGGER.error(response.toString(),e);
				return new ResponseEntity<Object>(response.toString(), status);
			}
		}else {
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3006.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3006.getMessage());					
			status= HttpStatus.NOT_IMPLEMENTED;
			return new ResponseEntity<Object>(response.toString(), status);
		}
			
	}
	
	@RequestMapping(value="/portal/details", method= RequestMethod.GET)
	public  ResponseEntity<Map<String,List<MarketPriceDetails>>> getMarketPriceDetails(){
		Map<String,List<MarketPriceDetails>> response=new HashMap<String,List<MarketPriceDetails>>();
		response.put(OlamFSPConstants.MARKET_DATA,marketpriceService.getMarketPriceDetails());
		
		return new ResponseEntity<Map<String,List<MarketPriceDetails>>>(response,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/portal/details", method= RequestMethod.POST)
	public ResponseEntity<Map<String,Object>> getMarketPriceDetailsInsert(@RequestBody(required=true) List<MarketPriceDetails> marketPriceUpdateList){
		Map<String,Object> response=marketpriceService.insertOrUpateMarketPrice(marketPriceUpdateList);
		HttpStatus status=(HttpStatus) response.get(OlamFSPConstants.STATUS);
		response.remove(OlamFSPConstants.STATUS);
		
		return new ResponseEntity<Map<String,Object>>(response,status);
		
	}
	@RequestMapping(value="/portal/details/{id}", method= RequestMethod.DELETE)
	public ResponseEntity<String> getMarketPriceDetailsDelete(@PathVariable("id") String id){
		HttpStatus status=null;
		JSONObject response =new JSONObject() ;
		if(marketpriceService.deleteMarketPriceRecord(id)) {
			status=HttpStatus.OK;
			response.put(OlamFSPConstants.STATUS, OlamFSPConstants.SUCCESS);
		}else {
			status=HttpStatus.NOT_MODIFIED;
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3002.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3002.getMessage());	
		}
		
		return new ResponseEntity<String>(response.toString(),status);
		
	}
	
	@RequestMapping(value="/portal/details", method= RequestMethod.DELETE)
	public ResponseEntity<String> getMarketPriceDetailsListDelete(@RequestBody(required=false) Map<String, List<String>> deleteidList){
		HttpStatus status=null;
		JSONObject response =new JSONObject() ;
		boolean isSuccess=true;
		if((null!=deleteidList&& !deleteidList.isEmpty())&&(deleteidList.containsKey(OlamFSPConstants.DELETE_KEY)&&!deleteidList.get(OlamFSPConstants.DELETE_KEY).isEmpty())) {
		for(String id:deleteidList.get(OlamFSPConstants.DELETE_KEY)) {
		boolean temp=	marketpriceService.deleteMarketPriceRecord(id);
		isSuccess=isSuccess?temp:isSuccess;
		}
		if(isSuccess) {
			status=HttpStatus.OK;
			response.put(OlamFSPConstants.STATUS, OlamFSPConstants.SUCCESS);
		}else {
			status=HttpStatus.NOT_MODIFIED;
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3005.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3005.getMessage());	
		}
		}else {
			status= HttpStatus.BAD_REQUEST;
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3003.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3003.getMessage());
		}
		return new ResponseEntity<String>(response.toString(),status);
		
	}
	
	@RequestMapping(value="/report", method= RequestMethod.GET)
	public ResponseEntity<Object> getMarketReportDetails(@RequestParam(name="id",required=false) String id){

		HttpStatus status = null;
		JSONObject response =new JSONObject() ;
        ObjectMapper mapperObj = new ObjectMapper();
		List<MarketPriceReportDetails> responseDetails= null;
		if(!StringUtils.isEmpty(id))
		{
			try {
				responseDetails=	marketpriceService.fetchProductPriceReport(id);
				return new ResponseEntity<Object>(response, HttpStatus.OK);
			}catch (Exception e) {
				
				response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3004.getErrorCode());
				response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3004.getMessage());					
				status= HttpStatus.INTERNAL_SERVER_ERROR;
				
				LOGGER.error("Error occured",e);
				return new ResponseEntity<Object>(response.toString(), status);
			}
		}else
		{
			status= HttpStatus.BAD_REQUEST;
			response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3003.getErrorCode());
			response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3003.getMessage());					
			
			return new ResponseEntity<Object>(response.toString(), status);
		}

	}
	
}
