package com.olam.marketprice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Entity
@Table(name="market_lang")
public class MarketLanguageModel {

	
	@Id
	@Column(name="name")
	private String name;	
	
	@Column(name="name_in_hindi")
	private String nameHindi;	
	
	
	@Column(name="name_in_telugu")
	private String nameTelugu;


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getNameHindi() {
		return nameHindi;
	}


	public void setNameHindi(String nameHindi) {
		this.nameHindi = nameHindi;
	}


	public String getNameTelugu() {
		return nameTelugu;
	}


	public void setNameTelugu(String nameTelugu) {
		this.nameTelugu = nameTelugu;
	}
	
}
