package com.olam.marketprice.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name="market_price")
@JsonInclude(value=Include.NON_NULL)
public class MarketPriceDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="market_price_id")
	private int id;	
		
	@Column(name="state")
	private String state;
	
	@Column(name="district")
	private String district;
	
	@Column(name="market_name")
	private String market;
	
	@Column(name="category")
	private String category;
	
	@Column(name = "commodity_name")
	private String product;
	
	@Column(name = "variety")
	private String variety;
	
	@Column(name="grade")
	private String grade;
	
	@Column(name="unit")
	private String unit;
	
	@Column(name="full_name")
	private String name;
	
	@Column(name="price")
	private double price;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name="active")
	private boolean active;
	
	
	@Column(name="min_price")
	private double min_price;
	
	@Column(name = "max_price")
	private double max_price;
	
	@Column(name = "created_at")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date createdTs;
	
	@Column(name = "updated_at")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date updatedTs;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name="min_price_flag")
	private int min_price_flag;
	
	@Column(name = "max_price_flag")
	private int max_price_flag;
	
	@Transient
	private String marketNameTelugu;
	@Transient
	private String marketNameHindi;
	@Transient
	private String nameHindi;
	@Transient
	private String nameTelugu;
	
	@Column(name="percentage")
	private String percentage;

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public double getMin_price() {
		return min_price;
	}

	public void setMin_price(double min_price) {
		this.min_price = min_price;
	}

	public double getMax_price() {
		return max_price;
	}

	public void setMax_price(double max_price) {
		this.max_price = max_price;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getVariety() {
		return variety;
	}

	public String getMarketNameTelugu() {
		return marketNameTelugu;
	}

	public void setMarketNameTelugu(String marketNameTelugu) {
		this.marketNameTelugu = marketNameTelugu;
	}

	public String getMarketNameHindi() {
		return marketNameHindi;
	}

	public void setMarketNameHindi(String marketNameHindi) {
		this.marketNameHindi = marketNameHindi;
	}

	public String getNameHindi() {
		return nameHindi;
	}

	public void setNameHindi(String nameHindi) {
		this.nameHindi = nameHindi;
	}

	public String getNameTelugu() {
		return nameTelugu;
	}

	public void setNameTelugu(String nameTelugu) {
		this.nameTelugu = nameTelugu;
	}

	public void setVariety(String variety) {
		this.variety = variety;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean getActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getMin_price_flag() {
		return min_price_flag;
	}

	public void setMin_price_flag(int min_price_flag) {
		this.min_price_flag = min_price_flag;
	}

	public int getMax_price_flag() {
		return max_price_flag;
	}

	public void setMax_price_flag(int max_price_flag) {
		this.max_price_flag = max_price_flag;
	}
	
}
