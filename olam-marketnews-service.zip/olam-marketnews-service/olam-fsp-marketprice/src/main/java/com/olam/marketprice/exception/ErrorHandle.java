package com.olam.marketprice.exception;

public interface ErrorHandle {

	int getErrorCode();
	String getMessage();
	
}
