package com.olam.marketprice.util;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.olam.marketprice.model.MarketPriceDetails;
import com.olam.marketprice.model.MarketPriceReportDetails;
import com.olam.marketprice.repository.MarketPriceReportRepository;
import com.olam.marketprice.repository.MarketPriceRepository;

//@Configuration
//@EnableBatchProcessing
public class MarketFeedSyncJob {

	private static final Logger LOG = LoggerFactory.getLogger(MarketFeedSyncJob.class);
	@Value("${chunkSize}")
	private int chunkSize;
	@Value("${marketFeedApiKey}")
	private String marketFeedApiKey;
	
	@Value("${marketFeedRecordLimit}")
	private int marketFeedRecordLimit;
	@Autowired
	ApplicationContext context;
	
	@Autowired
	MarketPriceRepository marketPriceRepository;
	
	@Autowired
	MarketPriceReportRepository marketPriceReportRepository;

	@Autowired
	RestTemplate restTemplate;

	private static final String MARKET_FEED_URL =
			"https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070?api-key={apikey}&format=json&offset={offset}&limit=10";

	@Autowired
	DataSource dataSource;

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job marketFeedDataSync() {

		return jobBuilderFactory.get("marketFeedSync").flow(marketFeedSyncStep()).build().build();

	}

	@Bean
	public Step marketFeedSyncStep() {

		return stepBuilderFactory.get("dbDumpReader").allowStartIfComplete(false).<String, List <MarketPriceDetails>>chunk(chunkSize)
				.reader(marketFeedApiReader()).processor(marketFeedProcessor()).writer(marketFeedWriter())
				.build();
	}
	@Bean
	@StepScope
	public ItemWriter< List<MarketPriceDetails>> marketFeedWriter() {
		
		return new ItemWriter<List<MarketPriceDetails>>() {
			
			@Override
			public void write(List<? extends List<MarketPriceDetails>> items) throws Exception {
				for( List<MarketPriceDetails> detailsList:items) {
					for(MarketPriceDetails details:detailsList) {
						MarketPriceDetails temp=marketPriceRepository.save(details);
						marketPriceReportRepository.save(generateReportEntry(temp));
					}
				}
				
			}

			private MarketPriceReportDetails generateReportEntry(MarketPriceDetails details) {
				MarketPriceReportDetails report=new MarketPriceReportDetails();
				report.setCreatedTs(new Date());
				report.setDistrict(details.getDistrict());
				report.setState(details.getState());
				report.setGrade(details.getGrade());
				report.setMax_price(details.getMax_price());
				report.setMin_price(details.getMin_price());
				report.setProduct(details.getProduct());
				report.setMarket(details.getMarket());
				report.setMarketProdId(details.getId());
				LOG.info("Product reference id-->"+details.getId());
				return report;
			}
		};
	}

	@Bean
	@StepScope
	public ItemProcessor< String, List<MarketPriceDetails>> marketFeedProcessor() {
		
		return new ItemProcessor<String, List<MarketPriceDetails>>() {
			
			@Override
			public List<MarketPriceDetails> process(String item) throws Exception {
				JSONObject dataJson=new JSONObject(item);
				List<MarketPriceDetails> response=new ArrayList<MarketPriceDetails>();
				JSONArray array=dataJson.getJSONArray("records");
				for(int i=0;i<array.length();i++) {
					JSONObject dataPrice=(JSONObject)(array.get(i));
					List<MarketPriceDetails> priceBDDet= marketPriceRepository.findProduct(dataPrice.getString("state"),dataPrice.getString("district"),dataPrice.getString("commodity"),dataPrice.getString("variety"),dataPrice.getString("market"),null,null);
					MarketPriceDetails priceDet;
					if(priceBDDet.size()==0) {
					 priceDet=new MarketPriceDetails();
					priceDet.setState(dataPrice.getString("state"));
					priceDet.setDistrict(dataPrice.getString("district"));
					priceDet.setProduct(dataPrice.getString("commodity"));
					priceDet.setMax_price(dataPrice.getDouble("max_price"));
					priceDet.setMin_price(dataPrice.getDouble("min_price"));
					priceDet.setGrade(dataPrice.getString("variety"));
					priceDet.setMarket(dataPrice.getString("market"));
					priceDet.setCreatedTs(new Date());
					priceDet.setUpdatedTs(new Date());
					priceDet.setMax_price_flag(0);
					priceDet.setMin_price_flag(0);
					priceDet.setCreatedBy("SYSTEM");
					LOG.info("Inserted new record "+dataPrice);
					}else {
						priceDet=priceBDDet.get(0);
						priceDet.setMax_price_flag(computeFlagValue(priceDet.getMax_price(),dataPrice.getDouble("max_price")));
						priceDet.setMin_price_flag(computeFlagValue(priceDet.getMin_price(),dataPrice.getDouble("min_price")));
						priceDet.setMin_price(dataPrice.getDouble("min_price"));
						priceDet.setMax_price(dataPrice.getDouble("max_price"));
						priceDet.setUpdatedTs(new Date());
						priceDet.setUpdatedBy("SYSTEM");
						LOG.info("updated record "+dataPrice);
					}
					response.add(priceDet);
				}
				return response;
			}

			private int computeFlagValue(double max_price, double double1) {
			
				return 	max_price>double1?-1:(max_price<double1?1:0);
			}
		};
	}

	@Bean
	@StepScope
	public ItemReader<String> marketFeedApiReader() {
		
		return new ItemReader<String>() {
			int offset=0;
			boolean isNotEndOfRecord=true;
			@Override
			public String read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
				String str = null;
				if(offset<marketFeedRecordLimit && this.isNotEndOfRecord) {
					 HttpHeaders headers = new HttpHeaders();
			         headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			         /*  headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36");
			         headers.add("Host","api.data.gov.in");*/
			       //  headers.add("Host","api.data.gov.in");
			         HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			        // restTemplate.setInterceptors(Collections.singletonList(new BasicAuthorizationInterceptor("9884928454", "ram1307@")));
				URI url = new UriTemplate(MARKET_FEED_URL).expand(marketFeedApiKey,offset);
				//RequestEntity<String> entity = new RequestEntity<String>(HttpMethod.GET, url);
				ResponseEntity<String> response = restTemplate.exchange(url,HttpMethod.GET,entity, String.class);
				//String response =restTemplate.getForObject(url,String.class);
				str=response.getBody();
				JSONArray array=new JSONObject(str).getJSONArray("records");
				if(array.length()<1) {
					this.isNotEndOfRecord=false;
					LOG.info("offset:"+ offset+"  End of record:"+str);
				}
				}
				LOG.info("Current offset:"+ offset);
				offset+=10;
				return str;
			}
		};
	}

	//@Scheduled(cron="0 0 0/6 * * ?")
	public void marketFeedSchedular() {
	 JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
             .toJobParameters();
	 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
	 try {
		jobLauncher.run((Job)context.getBean("marketFeedDataSync"), jobParameters);
	} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
			| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
		LOG.error("error while running batch",e);
	}
	}
	
}
