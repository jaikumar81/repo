package com.olam.marketprice.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name="market_products_report")
@JsonInclude(content=Include.NON_NULL)
public class MarketPriceReportDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="market_products_report_id")
	private int id;	
		
	@Column(name="state")
	private String state;
	
	@Column(name="district")
	private String district;
	
	@Column(name="market")
	private String market;
	
	@Column(name = "product")
	private String product;
	
	@Column(name="grade")
	private String grade;
	
	@Column(name="min_price")
	private double min_price;
	
	@Column(name = "max_price")
	private double max_price;
	
	@Column(name = "created_at")
	private Date createdTs;
	
	@Column(name = "updated_at")
	private Date updatedTs;
	
	@Column(name = "market_product_id")
	private Integer marketProdId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public double getMin_price() {
		return min_price;
	}

	public void setMin_price(double min_price) {
		this.min_price = min_price;
	}

	public double getMax_price() {
		return max_price;
	}

	public void setMax_price(double max_price) {
		this.max_price = max_price;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	public Integer getMarketProdId() {
		return marketProdId;
	}

	public void setMarketProdId(Integer marketProdId) {
		this.marketProdId = marketProdId;
	}
	
}
