package com.olam.marketprice.service;

import java.util.List;
import java.util.Map;

import com.olam.marketprice.model.MarketPriceDetails;
import com.olam.marketprice.model.MarketPriceReportDetails;

public interface MarketPriceService {

	List<MarketPriceDetails> getMarketPriceDetails();

	List<MarketPriceReportDetails> fetchProductPriceReport(String id);

	Map<String, Object> insertOrUpateMarketPrice(List<MarketPriceDetails> marketPriceUpdateList);

	List<MarketPriceDetails> getMarketPriceDetailsState(String state, String district, String market, String category, String variety, String name,String lang);

	boolean deleteMarketPriceRecord(String id);

}
