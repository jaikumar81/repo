package com.olam.marketprice.util;

public final class OlamFSPConstants {
	
	private OlamFSPConstants() {
		throw new IllegalStateException("Utility class");
	}

	public static final String ERROR="Error";
	public static final String ERROR_DESC="Error_Description";
	public static final String RESPONSE = "response";
	public static final String STATUS = "status";
	public static final String ADMIN = "admin";
	public static final boolean ACTIVE = true;
	public static final String MARKET_DATA = "marketPriceFeed";
	public static final String SUCCESS = "success";
	public static final String DELETE_KEY = "id";
	public static final String EMPTY_STRING = "";
	public static final String TELUGU = "telugu";
	public static final String HINDI = "hindi";

}
