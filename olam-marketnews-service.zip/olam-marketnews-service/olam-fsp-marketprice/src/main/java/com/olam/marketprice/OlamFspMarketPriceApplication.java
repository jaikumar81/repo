package com.olam.marketprice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
//@EnableScheduling
@EnableEurekaClient
//@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
//@EnableJpaRepositories(basePackages = {"com.olam.marketprice.repository"})
public class OlamFspMarketPriceApplication {
	
	private static final Logger LOG = LoggerFactory.getLogger(OlamFspMarketPriceApplication.class);

	public static void main(String[] args) {
	ApplicationContext context=	SpringApplication.run(OlamFspMarketPriceApplication.class, args);
	
	/*JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
            .toJobParameters();
	 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
	 try {
		jobLauncher.run((Job)context.getBean("marketFeedDataSync"), jobParameters);
	} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
			| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
		LOG.error("error while running batch",e);
	}*/

		
	}
}
