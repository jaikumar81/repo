package com.olam.marketprice.serviceImpl;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.olam.marketprice.exception.ErrorCode;
import com.olam.marketprice.model.MarketLanguageModel;
import com.olam.marketprice.model.MarketPriceDetails;
import com.olam.marketprice.model.MarketPriceReportDetails;
import com.olam.marketprice.repository.MarketLanguageRepository;
import com.olam.marketprice.repository.MarketPriceReportRepository;
import com.olam.marketprice.repository.MarketPriceRepository;
import com.olam.marketprice.service.MarketPriceService;
import com.olam.marketprice.util.OlamFSPConstants;

@Service
public class MarketPriceServiceImpl implements MarketPriceService {

	@Autowired
	MarketPriceRepository marketpriceRepo;
	
	@Autowired
	MarketPriceReportRepository marketPriceRepo;

	@Autowired
	MarketLanguageRepository marketLangRepo;
	
	@Override
	public List<MarketPriceDetails> getMarketPriceDetails() {
		

		List<MarketPriceDetails> responseList= new ArrayList<MarketPriceDetails>();
		
			responseList=marketpriceRepo.findAll();
			if(null!=responseList) {
			this.populateLangTags(responseList);
			}
		return null!=responseList?responseList:new ArrayList<MarketPriceDetails>();
	}

	@Override
	public List<MarketPriceReportDetails> fetchProductPriceReport(String id) {
		List<MarketPriceReportDetails> report= marketPriceRepo.findByMarketProdId(Integer.valueOf(id));
		return report;
	}

	private void populateLangTags(List<MarketPriceDetails> responseList) {
		for(MarketPriceDetails details:responseList) {
			MarketLanguageModel marketLang=	marketLangRepo.findByName(details.getMarket());
			MarketLanguageModel productLang=marketLangRepo.findByName(details.getName());
			
			if(null!=marketLang) {
			details.setMarketNameHindi(marketLang.getNameHindi());
			details.setMarketNameTelugu(marketLang.getNameTelugu());
			}
			if(null!=productLang) {
			details.setNameHindi(productLang.getNameHindi());
			details.setNameTelugu(productLang.getNameTelugu());
			}
		}
		
	}

	@Override
	public Map<String, Object> insertOrUpateMarketPrice(List<MarketPriceDetails> marketPriceUpdateList) {
		Map<String, Object> response=new HashMap<String, Object>();
				if(null!=marketPriceUpdateList&&!marketPriceUpdateList.isEmpty()) {
					for(MarketPriceDetails priceDet:marketPriceUpdateList) {
						if(0!=priceDet.getId()) {	
							marketpriceRepo.save(compareAndUpdateFlag(priceDet));
						}else {
						List<MarketPriceDetails> dbRecord=	marketpriceRepo.findProduct(priceDet.getState(), priceDet.getDistrict(),priceDet.getProduct(),StringUtils.isEmpty(priceDet.getGrade())?OlamFSPConstants.EMPTY_STRING:priceDet.getGrade(),priceDet.getMarket(),priceDet.getCategory(),priceDet.getVariety());
						insertOrUpdateMarketPriceDB(dbRecord,priceDet);
						}
						insertLanguageTags(priceDet);
					}
						response.put(OlamFSPConstants.STATUS, HttpStatus.OK);
						response.put(OlamFSPConstants.RESPONSE, OlamFSPConstants.SUCCESS);
				}else {
					response.put(OlamFSPConstants.STATUS, HttpStatus.BAD_REQUEST);
					response.put(OlamFSPConstants.ERROR, ErrorCode.FSP_TS_3003.getErrorCode());
					response.put(OlamFSPConstants.ERROR_DESC, ErrorCode.FSP_TS_3003.getMessage());
				}
		return response;
	}

	private void insertLanguageTags(MarketPriceDetails priceDet) {		
		
		if(!StringUtils.isEmpty(priceDet.getMarketNameHindi())&&null==marketLangRepo.findByName(priceDet.getMarket())) {
			insertLanguage(new MarketLanguageModel(),priceDet.getMarket(),priceDet.getMarketNameHindi(),priceDet.getMarketNameTelugu());
		}
		if(!StringUtils.isEmpty(priceDet.getNameHindi())&&null==marketLangRepo.findByName(priceDet.getName())) {
			insertLanguage(new MarketLanguageModel(),priceDet.getName(),priceDet.getNameHindi(),priceDet.getNameTelugu());
		}
	}
	private void insertLanguage(MarketLanguageModel lang, String name, String nameHindi,
			String nameTelugu) {
		lang.setName(name);
		lang.setNameHindi(nameHindi);
		lang.setNameTelugu(nameTelugu);
		marketLangRepo.save(lang);		
	}

	private MarketPriceDetails compareAndUpdateFlag(MarketPriceDetails priceDet) {

		MarketPriceDetails dbRecord = marketpriceRepo.findById(priceDet.getId());
		if (null != dbRecord) {
			priceDet.setMax_price_flag(computeFlagValue(priceDet.getPrice(), dbRecord.getPrice()));
			priceDet.setMin_price_flag(0);
			priceDet.setUpdatedTs(new Date());
			priceDet.setUpdatedBy(OlamFSPConstants.ADMIN);
			priceDet.setPercentage(computePercentageChange(priceDet.getPrice(), dbRecord.getPrice()));
		}else {
			priceDet.setActive(StringUtils.isEmpty(priceDet.getActive())?OlamFSPConstants.ACTIVE:priceDet.getActive());
			priceDet.setCreatedBy(OlamFSPConstants.ADMIN);
			priceDet.setGrade(StringUtils.isEmpty(priceDet.getGrade())?OlamFSPConstants.EMPTY_STRING:priceDet.getGrade());
			priceDet.setCreatedTs(new Date());
			priceDet.setMax_price_flag(0);
			priceDet.setMin_price_flag(0);
			priceDet.setPercentage("0%");
		}
		return priceDet;
	}
	private String computePercentageChange(double price, double price2) {
		DecimalFormat two = new DecimalFormat("0.00");
		two.setRoundingMode(RoundingMode.CEILING);
		if(price2>0) {
		double diff=price>price2?(price-price2):(price2-price);
		double percentage=(diff*100)/price2;
		
		return (two.format(percentage)+"%");
		
		}else {
			return "0%";
		}
	}

	private int computeFlagValue(double max_price, double double1) {
		
		return 	max_price<double1?-1:(max_price>double1?1:0);
	}
	private void insertOrUpdateMarketPriceDB(List<MarketPriceDetails> dbRecord, MarketPriceDetails priceDet) {
		if(null!=dbRecord&&dbRecord.size()>0) {
			priceDet.setId(dbRecord.get(0).getId());
			priceDet.setMax_price_flag(computeFlagValue(priceDet.getPrice(),dbRecord.get(0).getPrice()));
			priceDet.setGrade(StringUtils.isEmpty(priceDet.getGrade())?OlamFSPConstants.EMPTY_STRING:priceDet.getGrade());
			priceDet.setMin_price_flag(0);
			priceDet.setUpdatedTs(new Date());
			priceDet.setUpdatedBy(OlamFSPConstants.ADMIN);
		}else {
			priceDet.setActive(StringUtils.isEmpty(priceDet.getActive())?OlamFSPConstants.ACTIVE:priceDet.getActive());
			priceDet.setCreatedBy(OlamFSPConstants.ADMIN);
			priceDet.setGrade(StringUtils.isEmpty(priceDet.getGrade())?OlamFSPConstants.EMPTY_STRING:priceDet.getGrade());
			priceDet.setCreatedTs(new Date());
			priceDet.setMax_price_flag(0);
			priceDet.setMin_price_flag(0);
		}
		marketpriceRepo.save(priceDet);
	}

	@Override
	public List<MarketPriceDetails> getMarketPriceDetailsState(String state, String district, String market,
			String category, String variety, String name,String lang) {

		List<MarketPriceDetails> responseList = new ArrayList<MarketPriceDetails>();

		if (!StringUtils.isEmpty(district)) {
			responseList = marketpriceRepo.findByStateAndDistrictAndActive(state, district, OlamFSPConstants.ACTIVE);
		} else if (!StringUtils.isEmpty(state)) {
			responseList = marketpriceRepo.findByStateAndActive(state, OlamFSPConstants.ACTIVE);
		} else {
			responseList = marketpriceRepo.findByActive(OlamFSPConstants.ACTIVE);
		}
		responseList = generateFilteredResponse(responseList, market, category, variety, name);
		populateLanguageTags(lang,responseList);
		
		return responseList;
	}

	private void populateLanguageTags(String lang, List<MarketPriceDetails> responseList) {
		if(!StringUtils.isEmpty(lang)) {
		for(MarketPriceDetails details:responseList) {
			MarketLanguageModel marketLang=	marketLangRepo.findByName(details.getMarket());
			MarketLanguageModel productLang=marketLangRepo.findByName(details.getName());
				switch(lang.toLowerCase()) {
				case OlamFSPConstants.TELUGU :
					details.setMarket(null!=marketLang&&!StringUtils.isEmpty(marketLang.getNameTelugu())?marketLang.getNameTelugu():details.getMarket());
					details.setName(null!=productLang&&!StringUtils.isEmpty(productLang.getNameTelugu())?productLang.getNameTelugu():details.getName());
					break;
				case OlamFSPConstants.HINDI :
					details.setMarket(null!=marketLang&&!StringUtils.isEmpty(marketLang.getNameHindi())?marketLang.getNameHindi():details.getMarket());
					details.setName(null!=productLang&&!StringUtils.isEmpty(productLang.getNameHindi())?productLang.getNameHindi():details.getName());
					break;
				default:
					
					break;
			}
			
		}
		}
	}

	private List<MarketPriceDetails> generateFilteredResponse(List<MarketPriceDetails> responseList, String market,
			String category, String variety, String name) {
		List<MarketPriceDetails> response = new ArrayList<MarketPriceDetails>();
		for (MarketPriceDetails temp : responseList) {
			if (!StringUtils.isEmpty(market) && temp.getMarket().equalsIgnoreCase(market)) {
				response.add(temp);
			} else if (!StringUtils.isEmpty(category) && temp.getCategory().equalsIgnoreCase(category)) {
				response.add(temp);
			} else if (!StringUtils.isEmpty(variety) && temp.getVariety().equalsIgnoreCase(variety)) {
				response.add(temp);
			} else if (!StringUtils.isEmpty(name) && temp.getName().equalsIgnoreCase(name)) {
				response.add(temp);
			} else if (StringUtils.isEmpty(market) && StringUtils.isEmpty(category) && StringUtils.isEmpty(variety)
					&& StringUtils.isEmpty(name)) {
				response.add(temp);
			}

		}
		return response;
	}

	@Override
	public boolean deleteMarketPriceRecord(String id) {
	Optional<MarketPriceDetails> details=	marketpriceRepo.findById(Integer.valueOf(id));
		if(details.isPresent()) {
			marketpriceRepo.delete(details.get());
			return true;
		}
		return false;
	}

}
