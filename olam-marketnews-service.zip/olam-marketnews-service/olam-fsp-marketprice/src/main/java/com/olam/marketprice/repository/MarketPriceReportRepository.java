package com.olam.marketprice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olam.marketprice.model.MarketPriceReportDetails;

public interface MarketPriceReportRepository extends JpaRepository<MarketPriceReportDetails, Integer> {

	List<MarketPriceReportDetails> findByMarketProdId(Integer valueOf);


	
}
