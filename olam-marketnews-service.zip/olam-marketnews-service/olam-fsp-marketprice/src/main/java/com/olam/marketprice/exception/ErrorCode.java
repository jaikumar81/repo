package com.olam.marketprice.exception;

public enum ErrorCode implements ErrorHandle {
	FSP_TS_3001(3001, "Oops!!! Something went wrong, Please contact administrator"),
	
	FSP_TS_3002(3002, "No Data Found"),
	FSP_TS_3003(3003, "mandatory parameter is missing"),
	FSP_TS_3004(3004, "Internal Error"),
	FSP_TS_3005(3005, "Delete failed"),
	FSP_TS_3006(3006, "Language not supported");


	private final int errorCodeNumber;
	private final String message;

	ErrorCode(int errorCodeNumber, String message) {
		this.errorCodeNumber = errorCodeNumber;
		this.message = message;
	}

	@Override
	public int getErrorCode() {
		return this.errorCodeNumber;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

}
