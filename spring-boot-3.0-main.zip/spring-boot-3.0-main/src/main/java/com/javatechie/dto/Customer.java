package com.javatechie.dto;

public record Customer(int id,String name,String email,String gender) {
}
