package com.olam.od.batch;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableBatchProcessing
public class ODBatchJob {
	
	private static final Logger LOG = LoggerFactory.getLogger(ODBatchJob.class);
	@Autowired
	DataSource dataSource;
	
	@Autowired
	ApplicationContext context;

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	@Value("${chunkSize}")
	private int chunkSize;
	
	@Value("${fetchDataQuery}")
	private String fetchDataQuery;
	
	@Value("${statusId}")
	private String statusId;
	
	@Value("${updateStatusId}")
	private String updateStatusId;
	
	@Value("${updateDataQuery}")
	private String updateDataQuery;
	
	
	@Bean
	public Job odJob() {
		return jobBuilderFactory.get("ODJob").flow(odBatchStep()).build().build();
	}
	
	@Bean
	public Step odBatchStep() {
		return stepBuilderFactory.get("FileDumpReader").<Long, Long>chunk(chunkSize)
				.reader(configureItemreader()).writer(configureItemWriter())
				.build();
	}

	private JdbcBatchItemWriter<Long> configureItemWriter() {
		JdbcBatchItemWriter<Long> writer=new JdbcBatchItemWriterBuilder<Long>()
				.dataSource(dataSource)
				.sql(updateDataQuery)
				.itemPreparedStatementSetter(new ItemPreparedStatementSetter<Long>() {

					@Override
					public void setValues(Long item, PreparedStatement ps) throws SQLException {
						ps.setInt(1, Integer.valueOf(updateStatusId));
						ps.setLong(2, item);
						
					}
				})
				.build();
		return writer;
	}

	private JdbcCursorItemReader<Long> configureItemreader() {
		JdbcCursorItemReader<Long> reader=new JdbcCursorItemReader<Long>();
		reader.setDataSource(dataSource);
		reader.setSql(fetchDataQuery+statusId);
		reader.setRowMapper(new RowMapper<Long>() {
					
					@Override
					public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				           
					return rs.getLong(0);
					}
				})
				;
		return reader;
	}

	
	

 @Scheduled(cron="${ScheduleCron}")
	public void forecastSyncSchedular() {
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.toJobParameters();
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		try {
			jobLauncher.run((Job) context.getBean("odJob"), jobParameters);
		} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
				| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
			LOG.error("error while running batch", e);
		}
	}
}
