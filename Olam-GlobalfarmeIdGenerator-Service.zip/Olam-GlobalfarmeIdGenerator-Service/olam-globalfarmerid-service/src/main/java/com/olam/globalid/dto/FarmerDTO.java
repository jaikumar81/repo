package com.olam.globalid.dto;


import java.util.Date;

public class FarmerDTO  {


	private Long id;

	private Long farmerId;

	private String displayFarmerId;

	private String farmerFirstName;

	private String farmerLastName;

	private Long globalFamerId;

	private Long enumeratorId;

	private String countryIsoCode;

	private Date dateOfBirth;

	private String email;

	private Long villageId;

	private Long talukId;

	private Long districtId;

	private Long stateId;

	private String title;

	private String streetAddress;

	private Long countryId;

	private Long regionId;

	private Long placeId;

	private String gender;

	private String olamFarmerId;

	private String joinOlam;

	private Long farmerAge;

	private Long totalArea;

	private String farmerName;

	private String photo;

	private String signature;

	private Boolean consentFarmer;

	private Boolean consentOthers;

	private Boolean isActive;

	private boolean deletedFlag;

	private Double latitude;

	private Double longitude;

	private String nationalId;

	private Boolean fullySynced;

	private Boolean hasBankAccount;

	private Double creditBalance;

	private String createdBy;

	private String updatedBy;

	private Date createdTs;

	private Date updatedTs;

	private Long farmerGroupId;

	private Long tempFarmerId;

	private Long sectionId;

	private String postalCode;

	private String notes;

	private Long moderationStatusId;

	private Long buyingAgentId;

	private Long educationLevelId;

	private String uploadId;

	private Long blockStatusId;

	private String blockReasonText;

	private String isRestricted;

	private int appId;

	private int farmerType;

	private String language;

	private String status;

	public Long getBuyingAgentId() {
		return buyingAgentId;
	}

	public void setBuyingAgentId(Long buyingAgentId) {
		this.buyingAgentId = buyingAgentId;
	}

	public Long getModerationStatusId() {
		return moderationStatusId;
	}

	public void setModerationStatusId(Long moderationStatusId) {
		this.moderationStatusId = moderationStatusId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDisplayFarmerId() {
		return displayFarmerId;
	}

	public void setDisplayFarmerId(String displayFarmerId) {
		this.displayFarmerId = displayFarmerId;
	}

	public Long getEnumeratorId() {
		return enumeratorId;
	}

	public void setEnumeratorId(Long enumeratorId) {
		this.enumeratorId = enumeratorId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public Long getRegionId() {
		return regionId;
	}

	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	public Long getPlaceId() {
		return placeId;
	}

	public void setPlaceId(Long placeId) {
		this.placeId = placeId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getOlamFarmerId() {
		return olamFarmerId;
	}

	public void setOlamFarmerId(String olamFarmerId) {
		this.olamFarmerId = olamFarmerId;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public Boolean getConsentFarmer() {
		return consentFarmer;
	}

	public void setConsentFarmer(Boolean consentFarmer) {
		this.consentFarmer = consentFarmer;
	}

	public Boolean getConsentOthers() {
		return consentOthers;
	}

	public void setConsentOthers(Boolean consentOthers) {
		this.consentOthers = consentOthers;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public boolean isDeletedFlag() {
		return deletedFlag;
	}

	public void setDeletedFlag(boolean deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public Boolean getFullySynced() {
		return fullySynced;
	}

	public void setFullySynced(Boolean fullySynced) {
		this.fullySynced = fullySynced;
	}

	public Boolean getHasBankAccount() {
		return hasBankAccount;
	}

	public void setHasBankAccount(Boolean hasBankAccount) {
		this.hasBankAccount = hasBankAccount;
	}

	public Double getCreditBalance() {
		return creditBalance;
	}

	public void setCreditBalance(Double creditBalance) {
		this.creditBalance = creditBalance;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	public Long getFarmerGroupId() {
		return farmerGroupId;
	}

	public void setFarmerGroupId(Long farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Long getTempFarmerId() {
		return tempFarmerId;
	}

	public void setTempFarmerId(Long tempFarmerId) {
		this.tempFarmerId = tempFarmerId;
	}

	public Long getSectionId() {
		return sectionId;
	}

	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Long getEducationLevelId() {
		return educationLevelId;
	}

	public void setEducationLevelId(Long educationLevelId) {
		this.educationLevelId = educationLevelId;
	}

	public String getUploadId() {
		return uploadId;
	}

	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}

	public Long getGlobalFamerId() {
		return globalFamerId;
	}

	public void setGlobalFamerId(Long globalFamerId) {
		this.globalFamerId = globalFamerId;
	}

	public String getFarmerFirstName() {
		return farmerFirstName;
	}

	public void setFarmerFirstName(String farmerFirstName) {
		this.farmerFirstName = farmerFirstName;
	}

	public String getFarmerLastName() {
		return farmerLastName;
	}

	public void setFarmerLastName(String farmerLastName) {
		this.farmerLastName = farmerLastName;
	}

	public String getCountryIsoCode() {
		return countryIsoCode;
	}

	public void setCountryIsoCode(String countryIsoCode) {
		this.countryIsoCode = countryIsoCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getJoinOlam() {
		return joinOlam;
	}

	public void setJoinOlam(String joinOlam) {
		this.joinOlam = joinOlam;
	}

	public Long getFarmerAge() {
		return farmerAge;
	}

	public void setFarmerAge(Long farmerAge) {
		this.farmerAge = farmerAge;
	}

	public Long getTotalArea() {
		return totalArea;
	}

	public void setTotalArea(Long totalArea) {
		this.totalArea = totalArea;
	}

	public Long getBlockStatusId() {
		return blockStatusId;
	}

	public void setBlockStatusId(Long blockStatusId) {
		this.blockStatusId = blockStatusId;
	}

	public String getBlockReasonText() {
		return blockReasonText;
	}

	public void setBlockReasonText(String blockReasonText) {
		this.blockReasonText = blockReasonText;
	}

	public String getIsRestricted() {
		return isRestricted;
	}

	public void setIsRestricted(String isRestricted) {
		this.isRestricted = isRestricted;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public int getFarmerType() {
		return farmerType;
	}

	public void setFarmerType(int farmerType) {
		this.farmerType = farmerType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getVillageId() {
		return villageId;
	}

	public void setVillageId(Long villageId) {
		this.villageId = villageId;
	}

	public Long getTalukId() {
		return talukId;
	}

	public void setTalukId(Long talukId) {
		this.talukId = talukId;
	}

	public Long getDistrictId() {
		return districtId;
	}

	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public String getFarmerName() {
		return farmerName;
	}

	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Long getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(Long farmerId) {
		this.farmerId = farmerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
