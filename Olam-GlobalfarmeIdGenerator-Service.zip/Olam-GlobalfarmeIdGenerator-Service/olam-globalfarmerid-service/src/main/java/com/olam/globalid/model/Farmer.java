package com.olam.globalid.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "farmer",schema = "test")
@Where(clause = "deleted_flag=0")
public class Farmer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "farmer_id")
	private Long farmerId;

	@Column(name = "display_farmer_id")
	@Size(min = 0, max = 50)
	private String displayFarmerId;

	@Column(name = "farmer_first_name")
	private String farmerFirstName;

	@Column(name = "farmer_last_name")
	@Size(min = 0, max = 225)
	private String farmerLastName;

	@Column(name = "global_famer_id")
	private Long globalFamerId;

	@Column(name = "enumerator_id")
	private Long enumeratorId;

	@Column(name = "country_iso_code")
	@Size(min = 0, max = 225)
	private String countryIsoCode;

	@Column(name = "dob")
	private Date dateOfBirth;

	@Column(name = "email")
	private String email;

	@Column(name = "village_id")
	private Long villageId;

	@Column(name = "taluk_id")
	private Long talukId;

	@Column(name = "district_id")
	private Long districtId;

	@Column(name = "state_id")
	private Long stateId;

	@Column(name = "title")
	@Size(min = 0, max = 100)
	private String title;

	@Column(name = "street_address")
	@Size(min = 0, max = 100)
	private String streetAddress;

	@Column(name = "country_id")
	private Long countryId;

	@Column(name = "region_id")
	private Long regionId;

	@Column(name = "place_id")
	private Long placeId;

	@Column(name = "gender")
	private String gender;

	@Column(name = "olam_farmer_id")
	private String olamFarmerId;

	@Column(name = "join_olam")
	private String joinOlam;

	@Column(name = "farmer_age")
	private Long farmerAge;

	@Column(name = "total_area")
	private Long totalArea;

	@Column(name = "farmer_name")
	@Size(min = 0, max = 225)
	private String farmerName;

	@Column(name = "photo")
	private String photo;

	@Column(name = "signature")
	private String signature;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "consent_farmer")
	private Boolean consentFarmer;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "consent_others")
	private Boolean consentOthers;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "is_active")
	private Boolean isActive;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "deleted_flag")
	private boolean deletedFlag;

	@Column(name = "latitude")
	private Double latitude;

	@Column(name = "longitude")
	private Double longitude;

	@Column(name = "national_id")
	private String nationalId;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "fully_synced")
	private Boolean fullySynced;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "has_bank_account")
	private Boolean hasBankAccount;

	@Column(name = "credit_balance")
	private Double creditBalance;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "created_at")
	private Date createdTs;

	@Column(name = "updated_at")
	private Date updatedTs;

	@Column(name = "farmer_group_id")
	private Long farmerGroupId;

	@Column(name = "temp_farmer_id")
	private Long tempFarmerId;

	@Column(name = "section_id")
	private Long sectionId;

	@Column(name = "postal_code")
	private String postalCode;

	@Column(name = "notes")
	private String notes;

	@Column(name = "farmer_moderation_status_id")
	private Long moderationStatusId;

	@Column(name = "buying_agent_id")
	private Long buyingAgentId;

	@Column(name = "education_level_id")
	private Long educationLevelId;

	@Column(name = "upload_id")
	private String uploadId;

	@Column(name = "block_status_id")
	private Long blockStatusId;

	@Column(name = "block_reason_text")
	private String blockReasonText;

	@Column(name = "is_restricted")
	private String isRestricted;

	@Column(name = "app_id")
	private int appId;

	@Column(name = "farmer_type")
	private int farmerType;

	@Column(name = "language")
	private String language;

	@Column(name = "status")
	private String status;

	public Long getBuyingAgentId() {
		return buyingAgentId;
	}

	public void setBuyingAgentId(Long buyingAgentId) {
		this.buyingAgentId = buyingAgentId;
	}

	public Long getModerationStatusId() {
		return moderationStatusId;
	}

	public void setModerationStatusId(Long moderationStatusId) {
		this.moderationStatusId = moderationStatusId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDisplayFarmerId() {
		return displayFarmerId;
	}

	public void setDisplayFarmerId(String displayFarmerId) {
		this.displayFarmerId = displayFarmerId;
	}

	public Long getEnumeratorId() {
		return enumeratorId;
	}

	public void setEnumeratorId(Long enumeratorId) {
		this.enumeratorId = enumeratorId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public Long getRegionId() {
		return regionId;
	}

	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	public Long getPlaceId() {
		return placeId;
	}

	public void setPlaceId(Long placeId) {
		this.placeId = placeId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getOlamFarmerId() {
		return olamFarmerId;
	}

	public void setOlamFarmerId(String olamFarmerId) {
		this.olamFarmerId = olamFarmerId;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public Boolean getConsentFarmer() {
		return consentFarmer;
	}

	public void setConsentFarmer(Boolean consentFarmer) {
		this.consentFarmer = consentFarmer;
	}

	public Boolean getConsentOthers() {
		return consentOthers;
	}

	public void setConsentOthers(Boolean consentOthers) {
		this.consentOthers = consentOthers;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public boolean isDeletedFlag() {
		return deletedFlag;
	}

	public void setDeletedFlag(boolean deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public Boolean getFullySynced() {
		return fullySynced;
	}

	public void setFullySynced(Boolean fullySynced) {
		this.fullySynced = fullySynced;
	}

	public Boolean getHasBankAccount() {
		return hasBankAccount;
	}

	public void setHasBankAccount(Boolean hasBankAccount) {
		this.hasBankAccount = hasBankAccount;
	}

	public Double getCreditBalance() {
		return creditBalance;
	}

	public void setCreditBalance(Double creditBalance) {
		this.creditBalance = creditBalance;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public Date getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(Date updatedTs) {
		this.updatedTs = updatedTs;
	}

	public Long getFarmerGroupId() {
		return farmerGroupId;
	}

	public void setFarmerGroupId(Long farmerGroupId) {
		this.farmerGroupId = farmerGroupId;
	}

	public Long getTempFarmerId() {
		return tempFarmerId;
	}

	public void setTempFarmerId(Long tempFarmerId) {
		this.tempFarmerId = tempFarmerId;
	}

	public Long getSectionId() {
		return sectionId;
	}

	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Long getEducationLevelId() {
		return educationLevelId;
	}

	public void setEducationLevelId(Long educationLevelId) {
		this.educationLevelId = educationLevelId;
	}

	public String getUploadId() {
		return uploadId;
	}

	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}

	public Long getGlobalFamerId() {
		return globalFamerId;
	}

	public void setGlobalFamerId(Long globalFamerId) {
		this.globalFamerId = globalFamerId;
	}

	public String getFarmerFirstName() {
		return farmerFirstName;
	}

	public void setFarmerFirstName(String farmerFirstName) {
		this.farmerFirstName = farmerFirstName;
	}

	public String getFarmerLastName() {
		return farmerLastName;
	}

	public void setFarmerLastName(String farmerLastName) {
		this.farmerLastName = farmerLastName;
	}

	public String getCountryIsoCode() {
		return countryIsoCode;
	}

	public void setCountryIsoCode(String countryIsoCode) {
		this.countryIsoCode = countryIsoCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getJoinOlam() {
		return joinOlam;
	}

	public void setJoinOlam(String joinOlam) {
		this.joinOlam = joinOlam;
	}

	public Long getFarmerAge() {
		return farmerAge;
	}

	public void setFarmerAge(Long farmerAge) {
		this.farmerAge = farmerAge;
	}

	public Long getTotalArea() {
		return totalArea;
	}

	public void setTotalArea(Long totalArea) {
		this.totalArea = totalArea;
	}

	public Long getBlockStatusId() {
		return blockStatusId;
	}

	public void setBlockStatusId(Long blockStatusId) {
		this.blockStatusId = blockStatusId;
	}

	public String getBlockReasonText() {
		return blockReasonText;
	}

	public void setBlockReasonText(String blockReasonText) {
		this.blockReasonText = blockReasonText;
	}

	public String getIsRestricted() {
		return isRestricted;
	}

	public void setIsRestricted(String isRestricted) {
		this.isRestricted = isRestricted;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public int getFarmerType() {
		return farmerType;
	}

	public void setFarmerType(int farmerType) {
		this.farmerType = farmerType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getVillageId() {
		return villageId;
	}

	public void setVillageId(Long villageId) {
		this.villageId = villageId;
	}

	public Long getTalukId() {
		return talukId;
	}

	public void setTalukId(Long talukId) {
		this.talukId = talukId;
	}

	public Long getDistrictId() {
		return districtId;
	}

	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public String getFarmerName() {
		return farmerName;
	}

	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Long getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(Long farmerId) {
		this.farmerId = farmerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
