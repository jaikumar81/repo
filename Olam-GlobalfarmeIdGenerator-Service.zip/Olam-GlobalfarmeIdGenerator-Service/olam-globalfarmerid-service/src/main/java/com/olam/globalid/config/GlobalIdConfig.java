package com.olam.globalid.config;

import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.scheduling.annotation.Scheduled;

import com.olam.globalid.dto.FarmerDTO;
import com.olam.globalid.model.Farmer;
import com.olam.globalid.model.GlobalIdGenerator;
import com.olam.globalid.repository.FarmerRepository;
import com.olam.globalid.repository.GlobalIdRepository;
import com.olam.globalid.service.GlobalIdService;


@Configuration
@EnableBatchProcessing
public class GlobalIdConfig {
	
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	DataSource dataSource;
	
	@Autowired
	ApplicationContext context;
	
	@Autowired
	GlobalIdRepository globalIdRepository;
	
	@Autowired
	FarmerRepository farmerRepository;
	
	
	@Autowired
	GlobalIdService globalIdService;
	
	private static final Logger LOG = LoggerFactory.getLogger(GlobalIdConfig.class);
	
	private static final String QUERY_NEW_FARMERS = "select * from farmer where status = 'New'";
	
	@Bean
	public Job generateIdDump() {

		return jobBuilderFactory.get("generateIdDump").flow(generateIdSyncStep()).build().build();

	}
	
	@Bean
	public Step generateIdSyncStep() {

		return stepBuilderFactory.get("dbDumpReader").<FarmerDTO, FarmerDTO>chunk(5)
				.reader(generateIdReader()).writer(generateIdDetailedWriter())
				.build();
	}
	
	@Bean
	@StepScope
	public JdbcCursorItemReader<FarmerDTO> generateIdReader() {
		JdbcCursorItemReader<FarmerDTO> reader = new JdbcCursorItemReader<FarmerDTO>();
		try {
			reader.setDataSource(dataSource);
			reader.setSql(QUERY_NEW_FARMERS);
			reader.setRowMapper(new BeanPropertyRowMapper<FarmerDTO>(FarmerDTO.class));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return reader;
	}
	
	@StepScope
	@Bean
	public ItemWriter<FarmerDTO> generateIdDetailedWriter() {
		return new ItemWriter<FarmerDTO>() {
			@Override
			public void write(List<? extends FarmerDTO> items) throws Exception {
				GlobalIdGenerator globalIdGenerator = null;
				for(FarmerDTO item:items) {
					globalIdGenerator = new GlobalIdGenerator();
					globalIdGenerator.setId(item.getId());
					GlobalIdGenerator generator = globalIdRepository.save(globalIdGenerator);
					Farmer farmer = globalIdService.copyFromDTO(item);
					farmer.setGlobalFamerId(generator.getGobalFarmerId());
					farmerRepository.saveAndFlush(farmer);
				}
				
			}

		};
	}
	
	@Scheduled(cron="0 0/60 * * * ?")
	public void generateIdSchedular() {
	 JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
             .toJobParameters();
	 JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
	 try {
		jobLauncher.run((Job)context.getBean("generateIdDump"), jobParameters);
	} catch (BeansException | JobExecutionAlreadyRunningException | JobRestartException
			| JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
		LOG.error("error while running batch",e);
	}
	}

}
