package com.olam.globalid.repository;

import javax.persistence.PersistenceContext;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olam.globalid.model.Farmer;

@PersistenceContext(name="GlobalDataDW")
public interface FarmerRepository extends JpaRepository<Farmer, Long> {

}
