package com.olam.globalid.service;

import com.olam.globalid.dto.FarmerDTO;
import com.olam.globalid.model.Farmer;

public interface GlobalIdService {
	
	Farmer copyFromDTO(FarmerDTO farmerDTO);

}
