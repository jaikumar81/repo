package com.olam.globalid.repository;

import javax.persistence.PersistenceContext;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olam.globalid.model.GlobalIdGenerator;

@PersistenceContext(name="GlobalDataDW")
public interface GlobalIdRepository extends JpaRepository<GlobalIdGenerator, Long>{

}
