package com.olam.globalid.dto;

public class GlobalIdDTO {

}
