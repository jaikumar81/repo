package com.olam.globalid.serviceimpl;

import org.springframework.stereotype.Service;

import com.olam.globalid.dto.FarmerDTO;
import com.olam.globalid.model.Farmer;
import com.olam.globalid.service.GlobalIdService;

@Service
public class GlobalIdServiceImpl implements GlobalIdService {
	
	@Override
	public Farmer copyFromDTO(FarmerDTO farmerDTO) {
		Farmer farmer = new Farmer();
		String displayFarmerId = farmerDTO.getDisplayFarmerId();
		farmer.setDisplayFarmerId(displayFarmerId);
		farmer.setFarmerId(farmerDTO.getFarmerId());
		farmer.setId(farmerDTO.getId());
		farmer.setEmail(farmerDTO.getEmail());
		farmer.setBuyingAgentId(farmerDTO.getBuyingAgentId());
		farmer.setFarmerGroupId(farmerDTO.getFarmerGroupId());
		farmer.setTempFarmerId(farmerDTO.getTempFarmerId());
		farmer.setModerationStatusId(farmerDTO.getModerationStatusId());
		farmer.setEnumeratorId(farmerDTO.getEnumeratorId());
		farmer.setIsActive(farmerDTO.getIsActive());
		// deletedflag
		farmer.setPlaceId(farmerDTO.getPlaceId());
		farmer.setSectionId(farmerDTO.getSectionId());
		farmer.setPostalCode(farmerDTO.getPostalCode());
		farmer.setLanguage(farmerDTO.getLanguage());
		// farmerDto.setEducationLevelId(farmer.get);
		farmer.setCountryId(farmerDTO.getCountryId());
		farmer.setStreetAddress(farmerDTO.getStreetAddress());

		farmer.setStateId(farmerDTO.getStateId());
		farmer.setDistrictId(farmerDTO.getDistrictId());
		farmer.setTalukId(farmerDTO.getTalukId());
		farmer.setVillageId(farmerDTO.getVillageId());

		farmer.setRegionId(farmerDTO.getRegionId());
		farmer.setLatitude(farmerDTO.getLatitude());
		farmer.setLongitude(farmerDTO.getLongitude());
		farmer.setNationalId(farmerDTO.getNationalId());
		farmer.setPostalCode(farmerDTO.getPostalCode());
		farmer.setDateOfBirth(farmerDTO.getDateOfBirth());
		farmer.setGender(farmerDTO.getGender());
		farmer.setOlamFarmerId(farmerDTO.getOlamFarmerId());
		farmer.setPhoto(farmerDTO.getPhoto());
		farmer.setSignature(farmerDTO.getSignature());
		farmer.setConsentFarmer(farmerDTO.getConsentFarmer());
		farmer.setConsentOthers(farmerDTO.getConsentOthers());
		// farmerDto.setUploadId(farmer.getu);
		farmer.setFullySynced(farmerDTO.getFullySynced());
		farmer.setCreatedBy(farmerDTO.getCreatedBy());
		farmer.setUpdatedBy(farmerDTO.getUpdatedBy());
		farmer.setNotes(farmerDTO.getNotes());
		farmer.setAppId(farmerDTO.getAppId());
		farmer.setStatus("Active");

		// OD related members
		farmer.setGlobalFamerId(farmerDTO.getGlobalFamerId());
		farmer.setFarmerFirstName(farmerDTO.getFarmerFirstName());
		farmer.setFarmerLastName(farmerDTO.getFarmerLastName());
		farmer.setCountryIsoCode(farmerDTO.getCountryIsoCode());
		farmer.setJoinOlam(farmerDTO.getJoinOlam());
		farmer.setFarmerAge(farmerDTO.getFarmerAge());
		farmer.setTotalArea(farmerDTO.getTotalArea());
		// farmerDto.setVillage(farmer.getVillage());
		farmer.setDistrictId(farmerDTO.getDistrictId());
		farmer.setTitle(farmerDTO.getTitle());
		farmer.setFullySynced(farmerDTO.getFullySynced());
		farmer.setEmail(farmerDTO.getEmail());
		farmer.setCreatedTs(farmerDTO.getCreatedTs());
		farmer.setUpdatedTs(farmerDTO.getUpdatedTs());
		farmer.setFarmerType(farmerDTO.getFarmerType());
		farmer.setCreatedBy(farmerDTO.getCreatedBy());
		farmer.setUpdatedBy(farmerDTO.getUpdatedBy());
		farmer.setNotes(farmerDTO.getNotes());
		farmer.setAppId(farmerDTO.getAppId());
		farmer.setBlockStatusId(farmerDTO.getBlockStatusId());
		farmer.setBlockReasonText(farmerDTO.getBlockReasonText());

		return farmer;
	}

}
