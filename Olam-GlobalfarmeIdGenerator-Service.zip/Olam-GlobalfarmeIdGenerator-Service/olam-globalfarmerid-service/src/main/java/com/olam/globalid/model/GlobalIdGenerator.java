package com.olam.globalid.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "olam_globalid_generator",schema = "test")
public class GlobalIdGenerator {
	
	@Column(name = "id")
	private long id;
	
	@Id
	@Column(name = "global_farmer_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long globalFarmerId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getGobalFarmerId() {
		return globalFarmerId;
	}

	public void setGlobalFarmerId(Long globalFarmerId) {
		this.globalFarmerId = globalFarmerId;
	}
	
	
	
}
