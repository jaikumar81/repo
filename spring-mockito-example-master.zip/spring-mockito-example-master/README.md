# spring-mockito-example
How to write unit testing for controller using mockito(MockMVC)
