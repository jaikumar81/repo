# lookup-injection
Inject Prototype bean into Singleton bean
