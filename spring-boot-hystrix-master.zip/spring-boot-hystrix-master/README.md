# spring-boot-hystrix
How to enable hystrix circuit breaker in spring boot application 
